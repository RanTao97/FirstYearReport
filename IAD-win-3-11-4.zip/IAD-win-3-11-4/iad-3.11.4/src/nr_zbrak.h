void zbrak (double (*fx) (double), double x1, double x2, int n,
	    double xb1[], double xb2[], int *nb);
