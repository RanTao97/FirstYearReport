void gauleg (double x1, double x2, double x[], double w[], int n);
