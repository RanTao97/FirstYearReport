double rtsafe (void (*funcd) (double, double *, double *), double x1, double x2, double xacc);
