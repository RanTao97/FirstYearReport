void hooke(double **p, double y[], int nvars, double epsilon, double (*funk)(double []), int *nfunk);
