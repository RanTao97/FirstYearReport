#!/usr/bin/perl -pi.bak -w

s!/\*.*\n!!;
s!#line.*\n!!;

