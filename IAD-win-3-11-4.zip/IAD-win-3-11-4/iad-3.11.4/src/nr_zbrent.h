double zbrent(double (*func)(double), double x1, double x2, double tol);
