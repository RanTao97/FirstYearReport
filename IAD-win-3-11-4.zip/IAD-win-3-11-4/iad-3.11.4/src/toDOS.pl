#!/usr/bin/perl -pi.bak

s/\n/\015\012/;
