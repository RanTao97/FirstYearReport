

void Get_Phi (int n, int phase_function, double g, double **h);
