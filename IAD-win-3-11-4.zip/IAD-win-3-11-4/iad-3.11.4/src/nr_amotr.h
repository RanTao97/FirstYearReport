double
  amotry (double **p, double y[], double psum[], int ndim,
	  double (*funk) (double[]), int ihi, double fac);
