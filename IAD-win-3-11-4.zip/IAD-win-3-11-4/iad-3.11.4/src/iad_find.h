

void U_Find_Ba (struct measure_type m, struct invert_type *r);

void U_Find_Bs (struct measure_type m, struct invert_type *r);

void U_Find_A (struct measure_type m, struct invert_type *r);

void U_Find_B (struct measure_type m, struct invert_type *r);

void U_Find_G (struct measure_type m, struct invert_type *r);

void U_Find_AG (struct measure_type m, struct invert_type *r);

void U_Find_AB (struct measure_type m, struct invert_type *r);

void U_Find_BG (struct measure_type m, struct invert_type *r);

void U_Find_BaG (struct measure_type m, struct invert_type *r);

void U_Find_BsG (struct measure_type m, struct invert_type *r);
