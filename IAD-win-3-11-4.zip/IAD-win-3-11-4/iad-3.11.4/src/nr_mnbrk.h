void
  mnbrak (double *ax, double *bx, double *cx, double *fa, double *fb, double *fc,
	  double (*func) (double));
