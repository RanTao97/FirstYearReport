double
  brent (double ax, double bx, double cx, double (*f) (double), double tol,
	 double *xmin);
