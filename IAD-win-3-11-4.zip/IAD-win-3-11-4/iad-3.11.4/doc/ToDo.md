List of things that might or might not ever be done
===================================================

* revise manual

* improve error handling

* alter stderr output so that errors in processing produce ? instead of *

* Use cos_angle consistently between main program and the cone programs

* think about a simple sanity test to check releases

* add the ability to use the results of the last calculation