import numpy as np
import matplotlib.pyplot as plt
from os import path

from correct_spheres import correct_spheres

# set figure size and font size
plt.rcParams['figure.autolayout'] = True
plt.rcParams['axes.titlesize'] = 'x-large'
plt.rcParams['axes.labelsize'] = 'large'
plt.rcParams['xtick.labelsize'] = 'large'
plt.rcParams['ytick.labelsize'] = 'large'
plt.rcParams['legend.fontsize'] = 'large'

PATH_1 = "20230609/"
PATH_2 = "20230612_2/"

C_99_PATH = "D:/OneDrive - University of Cambridge/Integrating Sphere Calibration Standards/SRS-99-020/SRS-99-020.txt"

SPHERE_DIAMETER=50
SAMPLE_PORT_DIAMETER=10
ENTRANCE_PORT_DIAMETER=4.9
DETECTOR_PORT_DIAMETER=0.2
DETECTOR_REFLECTANCE=0

SPHERE_DIAMETER_2=SPHERE_DIAMETER
SAMPLE_PORT_DIAMETER_2=SAMPLE_PORT_DIAMETER
ENTRANCE_PORT_DIAMETER_2=0
DETECTOR_PORT_DIAMETER_2=DETECTOR_PORT_DIAMETER


class MeasData:
    def __init__(self, PATH, file):
        self.wavelength = np.loadtxt(PATH + file + "/1_R_OpenPort.txt", comments='#', usecols=0)
        self.R_open = np.loadtxt(PATH + file + "/1_R_OpenPort.txt", comments='#', usecols=1)
        self.R_ref = np.loadtxt(PATH + file + "/1_R_RefInPlace.txt", comments='#', usecols=1)
        self.T_block = np.loadtxt(PATH + file + "/1_T_BlockBeam.txt", comments='#', usecols=1)
        self.T_inc = np.loadtxt(PATH + file + "/1_T_IncBeam.txt", comments='#', usecols=1)

        """Read Calibration Standard 99%: Nominal Data"""
        C_lambda = np.loadtxt(C_99_PATH, skiprows=2, usecols=0)  # calibration wavelength
        C_99_nominal = np.loadtxt(C_99_PATH, skiprows=2, usecols=1)  # calibration values
        C_99_nominal = np.interp(self.wavelength, C_lambda, C_99_nominal)  # interpolated calibration values

        self.R1 = np.loadtxt(PATH + file + "/B/1_R_SampInPlace.txt", comments='#', usecols=1)
        self.T1 = np.loadtxt(PATH + file + "/B/1_T_SampInPlace.txt", comments='#', usecols=1)
        self.R2 = np.loadtxt(PATH + file + "/T/1_R_SampInPlace.txt", comments='#', usecols=1)
        self.T2 = np.loadtxt(PATH + file + "/T/1_T_SampInPlace.txt", comments='#', usecols=1)
        self.thickness1 = np.mean(np.loadtxt(PATH + file + "/B/thickness.txt", comments='#', usecols=0))
        self.thickness2 = np.mean(np.loadtxt(PATH + file + "/T/thickness.txt", comments='#', usecols=0))

        self.M_R1 = (self.R1 - self.R_open) / (self.R_ref - self.R_open) * C_99_nominal
        self.M_T1 = (self.T1 - self.T_block) / (self.T_inc - self.T_block)

        self.M_R2 = (self.R2 - self.R_open) / (self.R_ref - self.R_open) * C_99_nominal
        self.M_T2 = (self.T2 - self.T_block) / (self.T_inc - self.T_block)

    def plot_R_ref(self, ax, var_name):
        """
        helper function to plot R_ref
        :param ax: figure ax to plot
        :param var_name: measurement variable name
        :return: nothing
        """
        ax.plot(self.wavelength, self.R_ref, label=var_name)
        ax.legend()

    def plot_T_inc(self, ax, var_name):
        """
        helper function to plot T_inc
        :param ax: figure ax to plot
        :param var_name: measurement variable name
        :return: nothing
        """
        ax.plot(self.wavelength, self.T_inc, label=var_name)
        ax.legend()

    def plot_M_R(self, ax, var_name, c=None, alpha=1.0):
        """
        helper function to plot M_R
        :param ax: figure ax to plot
        :param var_name: measurement variable name
        :param c: colour to plot
        :param alpha: alpha of the colour
        :return: nothing
        """
        p = ax.plot(self.wavelength, self.M_R1, label=var_name, color=c, alpha=alpha)
        ax.plot(self.wavelength, self.M_R2, c=p[0].get_color(), alpha=alpha)
        ax.legend()
        ax.set_xlabel("Wavelength (nm)")
        ax.set_ylabel(r'$M_R$ (a.u.)')

    def plot_M_T(self, ax, var_name, c=None, alpha=1.0):
        """
        helper function to plot M_T
        :param ax: figure ax to plot
        :param var_name: measurement variable name
        :param c: colour to plot
        :param alpha: alpha of the colour
        :return: nothing
        """
        p = ax.plot(self.wavelength, self.M_T1, label=var_name, color=c, alpha=alpha)
        ax.plot(self.wavelength, self.M_T2, c=p[0].get_color(), alpha=alpha)
        ax.legend()
        ax.set_xlabel("Wavelength (nm)")
        ax.set_ylabel(r'$M_T$ (a.u.)')

class BioPixSDatasheet:
    def __init__(self, wave, mu_a, mu_sp):
        self.wave = wave
        self.mu_a = 0.1 * mu_a  # convert to [mm-1]
        self.mu_sp = 0.1 * mu_sp  # convert to [mm-1]
        self.prop_dict = None
        self.thickness_thin = None
        self.thickness_thick = None
        self.sim_RT_thin = None
        self.sim_RT_thick = None
        self.sim_M_R_M_T_985_thin = None
        self.sim_M_R_M_T_985_thick = None
        self.sim_M_R_M_T_rw_thin = None
        self.sim_M_R_M_T_rw_thick = None

    def load_sim_RT_thin(self, file_constant, file_thickness, thickness):
        """
        helper function to load RT when thickness = thin
        :param file_constant: path to Constants.npz
        :param file_thickness: path to folder of thin thickness
        :param thickness: thin thickness
        :return: nothing
        """
        self.thickness_thin = thickness
        # read simulation Constants.npz
        Constants = np.load(file_constant, allow_pickle=True)
        self.prop_dict = {
            "MU": Constants["MU"],
            "REFRACTIVE_INDEX_SAMPLE": Constants["REFRACTIVE_INDEX_SAMPLE"],
            "REFRACTIVE_INDEX_GLASS": Constants["REFRACTIVE_INDEX_GLASS"],
            "THICKNESS_SAMPLE": Constants["THICKNESS_SAMPLE"],
            "THICKNESS_GLASS": Constants["THICKNESS_GLASS"],
            "BEAM_DIAMETER": Constants["BEAM_DIAMETER"],
            "STANDARD_REFLECTANCE": Constants["STANDARD_REFLECTANCE"],
            "NUMBER_OF_SPHERES": Constants["NUMBER_OF_SPHERES"],
            "SPHERE_DIAMETER": Constants["SPHERE_DIAMETER"],
            "SAMPLE_PORT_DIAMETER": Constants["SAMPLE_PORT_DIAMETER"],
            "ENTRANCE_PORT_DIAMETER": Constants["ENTRANCE_PORT_DIAMETER"],
            "DETECTOR_PORT_DIAMETER": Constants["DETECTOR_PORT_DIAMETER"],
            "WALL_REFLECTANCE": Constants["WALL_REFLECTANCE"],
            "SPHERE_DIAMETER_2": Constants["SPHERE_DIAMETER_2"],
            "SAMPLE_PORT_DIAMETER_2": Constants["SAMPLE_PORT_DIAMETER_2"],
            "ENTRANCE_PORT_DIAMETER_2": Constants["ENTRANCE_PORT_DIAMETER_2"],
            "DETECTOR_PORT_DIAMETER_2": Constants["DETECTOR_PORT_DIAMETER_2"],
            "G": Constants["G"],
            "THETA": Constants["THETA"],
        }
        Constants.close()

        # an array to load sim_RT, simulated RT
        # row: each wavelength
        # col: wavelength, mu_a, mu_s', R_Disk, T_Disk, R_Diffuse, T_Diffuse
        sim_RT = np.zeros((len(self.wave), 7))
        # RT_Disk file
        RT_Disk = np.load(file_thickness + "/RT_Disk_lost.npy")
        RT_Diffuse = np.load(file_thickness + "/RT_Diffuse_lost.npy")
        for wave_idx, wave_val in enumerate(self.wave):
            mu_a = self.mu_a[wave_idx]
            mu_sp = self.mu_sp[wave_idx]

            sim_RT[wave_idx, 0] = wave_val
            idx = np.argmin((self.prop_dict["MU"][:, 0] - mu_a) ** 2 + (self.prop_dict["MU"][:, 1] - mu_sp) ** 2)
            sim_RT[wave_idx, 1] = self.prop_dict["MU"][idx, 0]
            sim_RT[wave_idx, 2] = self.prop_dict["MU"][idx, 1]
            # print(mu_a, self.prop_dict["MU"][idx, 0])
            # print(mu_sp, self.prop_dict["MU"][idx, 1])
            sim_RT[wave_idx, 3] = RT_Disk[idx, 0]
            sim_RT[wave_idx, 4] = RT_Disk[idx, 1]
            sim_RT[wave_idx, 5] = RT_Diffuse[idx, 0]
            sim_RT[wave_idx, 6] = RT_Diffuse[idx, 1]
        self.sim_RT_thin = sim_RT

    def load_sim_RT_thick(self, file_constant, file_thickness, thickness):
        """
        helper function to load RT when thickness = thick
        :param file_constant: path to Constants.npz
        :param file_thickness: path to folder of thick thickness
        :param thickness: thick thickness
        :return: nothing
        """
        self.thickness_thick = thickness
        # read simulation Constants.npz
        Constants = np.load(file_constant, allow_pickle=True)
        self.prop_dict = {
            "MU": Constants["MU"],
            "REFRACTIVE_INDEX_SAMPLE": Constants["REFRACTIVE_INDEX_SAMPLE"],
            "REFRACTIVE_INDEX_GLASS": Constants["REFRACTIVE_INDEX_GLASS"],
            "THICKNESS_SAMPLE": Constants["THICKNESS_SAMPLE"],
            "THICKNESS_GLASS": Constants["THICKNESS_GLASS"],
            "BEAM_DIAMETER": Constants["BEAM_DIAMETER"],
            "STANDARD_REFLECTANCE": Constants["STANDARD_REFLECTANCE"],
            "NUMBER_OF_SPHERES": Constants["NUMBER_OF_SPHERES"],
            "SPHERE_DIAMETER": Constants["SPHERE_DIAMETER"],
            "SAMPLE_PORT_DIAMETER": Constants["SAMPLE_PORT_DIAMETER"],
            "ENTRANCE_PORT_DIAMETER": Constants["ENTRANCE_PORT_DIAMETER"],
            "DETECTOR_PORT_DIAMETER": Constants["DETECTOR_PORT_DIAMETER"],
            "WALL_REFLECTANCE": Constants["WALL_REFLECTANCE"],
            "SPHERE_DIAMETER_2": Constants["SPHERE_DIAMETER_2"],
            "SAMPLE_PORT_DIAMETER_2": Constants["SAMPLE_PORT_DIAMETER_2"],
            "ENTRANCE_PORT_DIAMETER_2": Constants["ENTRANCE_PORT_DIAMETER_2"],
            "DETECTOR_PORT_DIAMETER_2": Constants["DETECTOR_PORT_DIAMETER_2"],
            "G": Constants["G"],
            "THETA": Constants["THETA"],
        }
        Constants.close()

        # an array to load sim_RT, simulated RT
        # row: each wavelength
        # col: wavelength, mu_a, mu_s', R_Disk, T_Disk, R_Diffuse, T_Diffuse
        sim_RT = np.zeros((len(self.wave), 7))
        # RT_Disk file
        RT_Disk = np.load(file_thickness + "/RT_Disk_lost.npy")
        RT_Diffuse = np.load(file_thickness + "/RT_Diffuse_lost.npy")
        for wave_idx, wave_val in enumerate(self.wave):
            mu_a = self.mu_a[wave_idx]
            mu_sp = self.mu_sp[wave_idx]

            sim_RT[wave_idx, 0] = wave_val
            idx = np.argmin((self.prop_dict["MU"][:, 0] - mu_a) ** 2 + (self.prop_dict["MU"][:, 1] - mu_sp) ** 2)
            sim_RT[wave_idx, 1] = self.prop_dict["MU"][idx, 0]
            sim_RT[wave_idx, 2] = self.prop_dict["MU"][idx, 1]
            # print(mu_a, MU[idx, 0])
            # print(mu_sp, MU[idx, 1])
            sim_RT[wave_idx, 3] = RT_Disk[idx, 0]
            sim_RT[wave_idx, 4] = RT_Disk[idx, 1]
            sim_RT[wave_idx, 5] = RT_Diffuse[idx, 0]
            sim_RT[wave_idx, 6] = RT_Diffuse[idx, 1]
        self.sim_RT_thick = sim_RT

    def correct_sphere_985(self):
        """
        helper function to do sphere correction when rw=0.985
        :return: nothing
        """
        """Read Calibration Standard 99%: Nominal Data"""
        C_lambda = np.loadtxt(C_99_PATH, skiprows=2, usecols=0)  # calibration wavelength
        C_99_nominal = np.loadtxt(C_99_PATH, skiprows=2, usecols=1)  # calibration values
        C_99_nominal = np.interp(self.wave, C_lambda, C_99_nominal)  # interpolated calibration values

        self.sim_M_R_M_T_985_thin = np.zeros((len(self.wave), 2))
        for wave_idx, wave_val in enumerate(self.wave):
            self.sim_M_R_M_T_985_thin[wave_idx, 0], self.sim_M_R_M_T_985_thin[wave_idx, 1] = correct_spheres(
            self.sim_RT_thin[wave_idx, 3], self.sim_RT_thin[wave_idx, 4],
            0.0, 0.0,
            self.sim_RT_thin[wave_idx, 5], self.sim_RT_thin[wave_idx, 6],
            self.prop_dict['THETA'],
            C_99_nominal[wave_idx], self.prop_dict['REFRACTIVE_INDEX_SAMPLE'],
            0.985, 0.985,
            0,
            SPHERE_DIAMETER, SAMPLE_PORT_DIAMETER,
            ENTRANCE_PORT_DIAMETER=ENTRANCE_PORT_DIAMETER, DETECTOR_PORT_DIAMETER=DETECTOR_PORT_DIAMETER)
        self.sim_M_R_M_T_985_thick = np.zeros((len(self.wave), 2))
        for wave_idx, wave_val in enumerate(self.wave):
            self.sim_M_R_M_T_985_thick[wave_idx, 0], self.sim_M_R_M_T_985_thick[wave_idx, 1] = correct_spheres(
                self.sim_RT_thick[wave_idx, 3], self.sim_RT_thick[wave_idx, 4],
                0.0, 0.0,
                self.sim_RT_thick[wave_idx, 5], self.sim_RT_thick[wave_idx, 6],
                self.prop_dict['THETA'],
                C_99_nominal[wave_idx], self.prop_dict['REFRACTIVE_INDEX_SAMPLE'],
                0.985, 0.985,
                0,
                SPHERE_DIAMETER, SAMPLE_PORT_DIAMETER,
                ENTRANCE_PORT_DIAMETER=ENTRANCE_PORT_DIAMETER, DETECTOR_PORT_DIAMETER=DETECTOR_PORT_DIAMETER)

    def correct_sphere_rw(self, rw_wave, rw_r, rw_t):
        """
        helper function to do sphere correction when input rw
        :param rw_wave: each wavelength of rw
        :param rw_r: rw of reflectance sphere at each wavelength
        :param rw_t: rw of transmittance sphere at each wavelength
        :return: nothing
        """
        """Read Calibration Standard 99%: Nominal Data"""
        C_lambda = np.loadtxt(C_99_PATH, skiprows=2, usecols=0)  # calibration wavelength
        C_99_nominal = np.loadtxt(C_99_PATH, skiprows=2, usecols=1)  # calibration values
        C_99_nominal = np.interp(self.wave, C_lambda, C_99_nominal)  # interpolated calibration values

        self.sim_M_R_M_T_rw_thin = np.zeros((len(self.wave), 2))
        for wave_idx, wave_val in enumerate(self.wave):
            self.sim_M_R_M_T_rw_thin[wave_idx, 0], self.sim_M_R_M_T_rw_thin[wave_idx, 1] = correct_spheres(
            self.sim_RT_thin[wave_idx, 3], self.sim_RT_thin[wave_idx, 4],
            0.0, 0.0,
            self.sim_RT_thin[wave_idx, 5], self.sim_RT_thin[wave_idx, 6],
            self.prop_dict['THETA'],
            C_99_nominal[wave_idx], self.prop_dict['REFRACTIVE_INDEX_SAMPLE'],
            rw_r[rw_wave == wave_val], rw_t[rw_wave == wave_val],
            0,
            SPHERE_DIAMETER, SAMPLE_PORT_DIAMETER,
            ENTRANCE_PORT_DIAMETER=ENTRANCE_PORT_DIAMETER, DETECTOR_PORT_DIAMETER=DETECTOR_PORT_DIAMETER)
        self.sim_M_R_M_T_rw_thick = np.zeros((len(self.wave), 2))
        for wave_idx, wave_val in enumerate(self.wave):
            self.sim_M_R_M_T_rw_thick[wave_idx, 0], self.sim_M_R_M_T_rw_thick[wave_idx, 1] = correct_spheres(
                self.sim_RT_thick[wave_idx, 3], self.sim_RT_thick[wave_idx, 4],
                0.0, 0.0,
                self.sim_RT_thick[wave_idx, 5], self.sim_RT_thick[wave_idx, 6],
                self.prop_dict['THETA'],
                C_99_nominal[wave_idx], self.prop_dict['REFRACTIVE_INDEX_SAMPLE'],
                rw_r[rw_wave == wave_val], rw_t[rw_wave == wave_val],
                0,
                SPHERE_DIAMETER, SAMPLE_PORT_DIAMETER,
                ENTRANCE_PORT_DIAMETER=ENTRANCE_PORT_DIAMETER, DETECTOR_PORT_DIAMETER=DETECTOR_PORT_DIAMETER)

    def plot_sim_M_R(self, ax):
        ax.scatter(self.wave, self.sim_M_R_M_T_985_thin[:, 0], c="tab:purple", marker="o",
                   label=f"0.985 thin={self.thickness_thin:.2f} mm")
        ax.scatter(self.wave, self.sim_M_R_M_T_985_thick[:, 0], c="tab:purple", marker="x",
                   label=f"0.985 thick={self.thickness_thick:.2f} mm")

        ax.scatter(self.wave, self.sim_M_R_M_T_rw_thin[:, 0], c="tab:red", marker="o",
                   label=r'$r_w$'+f" thin={self.thickness_thin:.2f} mm")
        ax.scatter(self.wave, self.sim_M_R_M_T_rw_thick[:, 0], c="tab:red", marker="x",
                   label=r'$r_w$'+f" thick={self.thickness_thick:.2f} mm")
        ax.legend()
        ax.set_xlabel("Wavelength (nm)")
        ax.set_ylabel(r'$M_R$ (a.u.)')

    def plot_sim_M_T(self, ax):
        ax.scatter(self.wave, self.sim_M_R_M_T_985_thin[:, 1], c="tab:purple", marker="o",
                   label=f"0.985 thin={self.thickness_thin:.2f} mm")
        ax.scatter(self.wave, self.sim_M_R_M_T_985_thick[:, 1], c="tab:purple", marker="x",
                   label=f"0.985 thick={self.thickness_thick:.2f} mm")
        ax.vlines(self.wave, self.sim_M_R_M_T_985_thick[:, 1], self.sim_M_R_M_T_985_thin[:, 1],
                   colors="tab:purple", alpha=0.5)

        ax.scatter(self.wave, self.sim_M_R_M_T_rw_thin[:, 1], c="tab:red", marker="o",
                   label=r'$r_w$'+f" thin={self.thickness_thin:.2f} mm")
        ax.scatter(self.wave, self.sim_M_R_M_T_rw_thick[:, 1], c="tab:red", marker="x",
                   label=r'$r_w$'+f" thick={self.thickness_thick:.2f} mm")
        ax.vlines(self.wave, self.sim_M_R_M_T_rw_thick[:, 1], self.sim_M_R_M_T_rw_thin[:, 1],
                  colors="tab:red", alpha=0.5)
        ax.legend()
        ax.set_xlabel("Wavelength (nm)")
        ax.set_ylabel(r'$M_T$ (a.u.)')

if __name__ == '__main__':
    """Load rw"""
    rw_wave = np.arange(450, 951, 1)
    rw_r = np.load("rw_r_20230606.npy")
    rw_t = np.load("rw_t_20230606.npy")

    """Read BioPixS Datasheet"""
    A2_BioPixS = BioPixSDatasheet(wave=np.array([600, 780]), mu_a=np.array([0.06, 0.05]), mu_sp=np.array([7.3, 5.4]))
    B3_BioPixS = BioPixSDatasheet(wave=np.array([500, 600, 690, 740, 780, 830, 900, 950]),
                                  mu_a=np.array([0.12, 0.12, 0.11, 0.12, 0.1, 0.1, 0.16, 0.11]),
                                  mu_sp=np.array([15, 13.1, 11.5, 10.7, 10, 9.2, 8.2, 7.7]))
    B7_BioPixS = BioPixSDatasheet(wave=np.array([500, 600, 780, 900]),
                                  mu_a=np.array([0.36, 0.36, 0.31, 0.38]), mu_sp=np.array([15, 13.5, 10.5, 8.9]))
    C5_BioPixS = BioPixSDatasheet(wave=np.array([600, 780]), mu_a=np.array([0.24, 0.21]), mu_sp=np.array([19.8, 15.4]))
    D7_BioPixS = BioPixSDatasheet(wave=np.array([600, 780]), mu_a=np.array([0.35, 0.3]), mu_sp=np.array([25.6, 19.8]))

    """To Plot M_R, M_T"""
    _, ax_A2_M_T = plt.subplots(num="A2 M_T Reproducibility")
    _, ax_B3_M_T = plt.subplots(num="B3 M_T Reproducibility")
    _, ax_B7_M_T = plt.subplots(num="B7 M_T Reproducibility")
    _, ax_C5_M_T = plt.subplots(num="C5 M_T Reproducibility")
    _, ax_D7_M_T = plt.subplots(num="D7 M_T Reproducibility")
    _, ax_A2_M_R = plt.subplots(num="A2 M_R Reproducibility")
    _, ax_B3_M_R = plt.subplots(num="B3 M_R Reproducibility")
    _, ax_B7_M_R = plt.subplots(num="B7 M_R Reproducibility")
    _, ax_C5_M_R = plt.subplots(num="C5 M_R Reproducibility")
    _, ax_D7_M_R = plt.subplots(num="D7 M_R Reproducibility")

    # """Black Tape 1"""
    # A2_black_1 = MeasData(PATH_1, "BlackTape/BioPixS_A2")
    # B3_black_1 = MeasData(PATH_1, "BlackTape/BioPixS_B3")
    # B7_black_1 = MeasData(PATH_1, "BlackTape/BioPixS_B7")
    # C5_black_1 = MeasData(PATH_1, "BlackTape/BioPixS_C5")
    # D7_black_1 = MeasData(PATH_1, "BlackTape/BioPixS_D7")
    # print(f"Black Tape 1 Thickness: A2 = ({A2_black_1.thickness1},{A2_black_1.thickness2}) mm\t"
    #       f"B3 = ({B3_black_1.thickness1},{B3_black_1.thickness2}) mm\t"
    #       f"B7 = ({B7_black_1.thickness1},{B7_black_1.thickness2}) mm\t"
    #       f"C5 = ({C5_black_1.thickness1},{C5_black_1.thickness2}) mm\t"
    #       f"D7 = ({D7_black_1.thickness1},{D7_black_1.thickness2}) mm\t")
    # A2_black_1.plot_M_T(ax_A2_M_T, "Black Tape 1")
    # B3_black_1.plot_M_T(ax_B3_M_T, "Black Tape 1")
    # B7_black_1.plot_M_T(ax_B7_M_T, "Black Tape 1")
    # C5_black_1.plot_M_T(ax_C5_M_T, "Black Tape 1")
    # D7_black_1.plot_M_T(ax_D7_M_T, "Black Tape 1")
    # A2_black_1.plot_M_R(ax_A2_M_R, "Black Tape 1")
    # B3_black_1.plot_M_R(ax_B3_M_R, "Black Tape 1")
    # B7_black_1.plot_M_R(ax_B7_M_R, "Black Tape 1")
    # C5_black_1.plot_M_R(ax_C5_M_R, "Black Tape 1")
    # D7_black_1.plot_M_R(ax_D7_M_R, "Black Tape 1")

    """No Tape"""
    A2_no = MeasData(PATH_1, "NoTape/BioPixS_A2")
    B3_no = MeasData(PATH_1, "NoTape/BioPixS_B3")
    B7_no = MeasData(PATH_1, "NoTape/BioPixS_B7")
    C5_no = MeasData(PATH_1, "NoTape/BioPixS_C5")
    D7_no = MeasData(PATH_1, "NoTape/BioPixS_D7")
    A2_no.plot_M_T(ax_A2_M_T, "No Tape", c="tab:gray")
    B3_no.plot_M_T(ax_B3_M_T, "No Tape", c="tab:gray")
    B7_no.plot_M_T(ax_B7_M_T, "No Tape", c="tab:gray")
    C5_no.plot_M_T(ax_C5_M_T, "No Tape", c="tab:gray")
    D7_no.plot_M_T(ax_D7_M_T, "No Tape", c="tab:gray")
    A2_no.plot_M_R(ax_A2_M_R, "No Tape", c="tab:gray")
    B3_no.plot_M_R(ax_B3_M_R, "No Tape", c="tab:gray")
    B7_no.plot_M_R(ax_B7_M_R, "No Tape", c="tab:gray")
    C5_no.plot_M_R(ax_C5_M_R, "No Tape", c="tab:gray")
    D7_no.plot_M_R(ax_D7_M_R, "No Tape", c="tab:gray")

    """Black Tape 2"""
    A2_black_2 = MeasData(PATH_2, "BlackTape/BioPixS_A2")
    B3_black_2 = MeasData(PATH_2, "BlackTape/BioPixS_B3")
    B7_black_2 = MeasData(PATH_2, "BlackTape/BioPixS_B7")
    C5_black_2 = MeasData(PATH_2, "BlackTape/BioPixS_C5")
    D7_black_2 = MeasData(PATH_2, "BlackTape/BioPixS_D7")
    print(f"Black Tape 2 Thickness: A2 = ({A2_black_2.thickness1},{A2_black_2.thickness2}) mm\t"
          f"B3 = ({B3_black_2.thickness1},{B3_black_2.thickness2}) mm\t"
          f"B7 = ({B7_black_2.thickness1},{B7_black_2.thickness2}) mm\t"
          f"C5 = ({C5_black_2.thickness1},{C5_black_2.thickness2}) mm\t"
          f"D7 = ({D7_black_2.thickness1},{D7_black_2.thickness2}) mm\t")
    A2_black_2.plot_M_T(ax_A2_M_T, "Black Tape", c="black")
    B3_black_2.plot_M_T(ax_B3_M_T, "Black Tape", c="black")
    B7_black_2.plot_M_T(ax_B7_M_T, "Black Tape", c="black")
    C5_black_2.plot_M_T(ax_C5_M_T, "Black Tape", c="black")
    D7_black_2.plot_M_T(ax_D7_M_T, "Black Tape", c="black")
    A2_black_2.plot_M_R(ax_A2_M_R, "Black Tape", c="black")
    B3_black_2.plot_M_R(ax_B3_M_R, "Black Tape", c="black")
    B7_black_2.plot_M_R(ax_B7_M_R, "Black Tape", c="black")
    C5_black_2.plot_M_R(ax_C5_M_R, "Black Tape", c="black")
    D7_black_2.plot_M_R(ax_D7_M_R, "Black Tape", c="black")

    """Green Tape"""
    A2_green = MeasData(PATH_2, "GreenTape/BioPixS_A2")
    B3_green = MeasData(PATH_2, "GreenTape/BioPixS_B3")
    B7_green = MeasData(PATH_2, "GreenTape/BioPixS_B7")
    C5_green = MeasData(PATH_2, "GreenTape/BioPixS_C5")
    D7_green = MeasData(PATH_2, "GreenTape/BioPixS_D7")
    A2_green.plot_M_T(ax_A2_M_T, "Cyan Tape", c="turquoise", alpha=0.5)
    B3_green.plot_M_T(ax_B3_M_T, "Cyan Tape", c="turquoise", alpha=0.5)
    B7_green.plot_M_T(ax_B7_M_T, "Cyan Tape", c="turquoise", alpha=0.5)
    C5_green.plot_M_T(ax_C5_M_T, "Cyan Tape", c="turquoise", alpha=0.5)
    D7_green.plot_M_T(ax_D7_M_T, "Cyan Tape", c="turquoise", alpha=0.5)
    A2_green.plot_M_R(ax_A2_M_R, "Cyan Tape", c="turquoise", alpha=0.5)
    B3_green.plot_M_R(ax_B3_M_R, "Cyan Tape", c="turquoise", alpha=0.5)
    B7_green.plot_M_R(ax_B7_M_R, "Cyan Tape", c="turquoise", alpha=0.5)
    C5_green.plot_M_R(ax_C5_M_R, "Cyan Tape", c="turquoise", alpha=0.5)
    D7_green.plot_M_R(ax_D7_M_R, "Cyan Tape", c="turquoise", alpha=0.5)

    """Calculate Simulated M_R, M_T"""
    A2_BioPixS.load_sim_RT_thin(
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_A2/Constants.npz",
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_A2/thickness2600um",
        thickness=2.60)
    A2_BioPixS.load_sim_RT_thick(
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_A2/Constants.npz",
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_A2/thickness2640um",
        thickness=2.64)
    A2_BioPixS.correct_sphere_985()
    A2_BioPixS.correct_sphere_rw(rw_wave, rw_r, rw_t)
    A2_BioPixS.plot_sim_M_T(ax_A2_M_T)
    A2_BioPixS.plot_sim_M_R(ax_A2_M_R)

    B3_BioPixS.load_sim_RT_thin(
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_B3/Constants.npz",
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_B3/thickness2340um",
        thickness=2.34)
    B3_BioPixS.load_sim_RT_thick(
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_B3/Constants.npz",
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_B3/thickness2400um",
        thickness=2.40)
    B3_BioPixS.correct_sphere_985()
    B3_BioPixS.correct_sphere_rw(rw_wave, rw_r, rw_t)
    B3_BioPixS.plot_sim_M_T(ax_B3_M_T)
    B3_BioPixS.plot_sim_M_R(ax_B3_M_R)

    B7_BioPixS.load_sim_RT_thin(
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_B7/Constants.npz",
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_B7/thickness2620um",
        thickness=2.62)
    B7_BioPixS.load_sim_RT_thick(
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_B7/Constants.npz",
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_B7/thickness2660um",
        thickness=2.66)
    B7_BioPixS.correct_sphere_985()
    B7_BioPixS.correct_sphere_rw(rw_wave, rw_r, rw_t)
    B7_BioPixS.plot_sim_M_T(ax_B7_M_T)
    B7_BioPixS.plot_sim_M_R(ax_B7_M_R)

    C5_BioPixS.load_sim_RT_thin(
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_C5/Constants.npz",
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_C5/thickness2580um",
        thickness=2.58)
    C5_BioPixS.load_sim_RT_thick(
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_C5/Constants.npz",
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_C5/thickness2640um",
        thickness=2.64)
    C5_BioPixS.correct_sphere_985()
    C5_BioPixS.correct_sphere_rw(rw_wave, rw_r, rw_t)
    C5_BioPixS.plot_sim_M_T(ax_C5_M_T)
    C5_BioPixS.plot_sim_M_R(ax_C5_M_R)

    D7_BioPixS.load_sim_RT_thin(
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_D7/Constants.npz",
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_D7/thickness2360um",
        thickness=2.36)
    D7_BioPixS.load_sim_RT_thick(
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_D7/Constants.npz",
        "D:/OneDrive - University of Cambridge/DIS_twin/Data_WMC/20230612_BioPixS_D7/thickness2400um",
        thickness=2.40)
    D7_BioPixS.correct_sphere_985()
    D7_BioPixS.correct_sphere_rw(rw_wave, rw_r, rw_t)
    D7_BioPixS.plot_sim_M_T(ax_D7_M_T)
    D7_BioPixS.plot_sim_M_R(ax_D7_M_R)




    plt.show()


