import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import UnivariateSpline
from os import path

from SPHERE_T import SPHERE_T
from SPHERE_R import SPHERE_R
from correct_spheres import correct_spheres

# set figure size and font size
plt.rcParams['figure.autolayout'] = True
plt.rcParams['axes.titlesize'] = 'x-large'
plt.rcParams['axes.labelsize'] = 'large'
plt.rcParams['xtick.labelsize'] = 'large'
plt.rcParams['ytick.labelsize'] = 'large'
plt.rcParams['legend.fontsize'] = 'large'

PATH = "20230606_1/"

SPHERE_DIAMETER=50
SAMPLE_PORT_DIAMETER=10
ENTRANCE_PORT_DIAMETER=4.9
DETECTOR_PORT_DIAMETER=0.2
DETECTOR_REFLECTANCE=0

SPHERE_DIAMETER_2=SPHERE_DIAMETER
SAMPLE_PORT_DIAMETER_2=SAMPLE_PORT_DIAMETER
ENTRANCE_PORT_DIAMETER_2=0
DETECTOR_PORT_DIAMETER_2=DETECTOR_PORT_DIAMETER

class MeasData:
    def __init__(self, file, C_99, R_open, R_ref, T_block, T_inc):
        wavelength = np.loadtxt(PATH + file + "/1_R_SampInPlace.txt", comments='#', usecols=0)
        R = np.loadtxt(PATH + file + "/1_R_SampInPlace.txt", comments='#', usecols=1)
        T = np.loadtxt(PATH + file + "/1_T_SampInPlace.txt", comments='#', usecols=1)
        self.M_R = (R - R_open) / (R_ref - R_open) * C_99
        self.M_T = (T - T_block) / (T_inc - T_block)
        if path.isfile(PATH + file + "/thickness.txt"):
            self.thickness = np.mean(np.loadtxt(PATH + file + "/thickness.txt", comments='#', usecols=0))

if __name__ == '__main__':
    """Read rw_r and P_20230602"""
    rw_r_20230602 = np.load("rw_r_20230602.npy")
    P_20230602 = np.load("P_20230602.npy")

    """Calibration to SRS-99"""
    wavelength = np.loadtxt(PATH + "1_R_OpenPort.txt", comments='#', usecols=0)
    R_open = np.loadtxt(PATH + "1_R_OpenPort.txt", comments='#', usecols=1)
    R_ref = np.loadtxt(PATH + "1_R_RefInPlace.txt", comments='#', usecols=1)
    T_block = np.loadtxt(PATH + "1_T_BlockBeam.txt", comments='#', usecols=1)
    T_inc = np.loadtxt(PATH + "1_T_IncBeam.txt", comments='#', usecols=1)

    plt.figure("Measurement Calibration by 99%")
    plt.plot(wavelength, R_open, label="R_open")
    plt.plot(wavelength, R_ref, label="R_ref")
    plt.plot(wavelength, T_block, label="T_block")
    plt.plot(wavelength, T_inc, label="T_inc")
    plt.legend()

    """Read Calibration Standard: Nominal Data"""
    C_lambda = np.loadtxt(
        "D:/OneDrive - University of Cambridge/Integrating Sphere Calibration Standards/SRS-99-020/SRS-99-020.txt",
        skiprows=2, usecols=0)  # calibration wavelength
    C_99_nominal = np.loadtxt(
        "D:/OneDrive - University of Cambridge/Integrating Sphere Calibration Standards/SRS-99-020/SRS-99-020.txt",
        skiprows=2, usecols=1)  # calibration values
    C_99_nominal = np.interp(wavelength, C_lambda, C_99_nominal)  # interpolated calibration values

    """Read R and T of Air"""
    R_air_meas = np.loadtxt(PATH + "Air" + "/1_R_SampInPlace.txt", comments='#', usecols=1) - R_open
    T_air_meas = np.loadtxt(PATH + "TRSwap_Air" + "/1_R_SampInPlace.txt", comments='#', usecols=1) -\
                 np.loadtxt(PATH + "TRSwap_Blk" + "/1_R_SampInPlace.txt", comments='#', usecols=1)
    plt.figure("Air")
    plt.plot(wavelength, T_air_meas, label="T_air_meas")
    plt.plot(wavelength, R_air_meas, label="R_air_meas")
    plt.legend()

    """Plot rw_r"""
    plt.figure("rw")
    plt.plot(wavelength, rw_r_20230602, label="rw_r from LabSphere 20230602")

    """R/T Ratio, Work out rw_r"""
    as_r = (SAMPLE_PORT_DIAMETER / SPHERE_DIAMETER) ** 2 / 4  # sample aperture
    ae_r = (ENTRANCE_PORT_DIAMETER / SPHERE_DIAMETER) ** 2 / 4  # entrance aperture
    ad_r = (DETECTOR_PORT_DIAMETER / SPHERE_DIAMETER) ** 2 / 4  # detector aperture
    aw_r = 1 - as_r - ae_r - ad_r
    rw_r_20230606 = (R_air_meas/T_air_meas) / ((R_air_meas/T_air_meas) * aw_r + (1 - ae_r) * as_r)
    spl = UnivariateSpline(wavelength, rw_r_20230606, s=1.5e-5)
    rw_r_spline = spl(wavelength)
    plt.figure("rw")
    plt.plot(wavelength, rw_r_20230606, label="rw_r_20230606")
    plt.plot(wavelength, rw_r_spline, label="Smooth rw_r_20230606")
    plt.legend()
    T_air_scale = R_air_meas * (1 - aw_r * rw_r_20230602) / ((1 - ae_r) * rw_r_20230602 * as_r)
    plt.figure("Air")
    plt.plot(wavelength, T_air_scale, label="T_air_scale")

    plt.figure("R/T")
    plt.plot(wavelength, R_air_meas/T_air_meas)

    """From Calibration Standard, Work out P"""
    P_20230606 = np.zeros_like(P_20230602)
    sphere_T = SPHERE_T(SPHERE_DIAMETER_2=SPHERE_DIAMETER_2, SAMPLE_PORT_DIAMETER_2=SAMPLE_PORT_DIAMETER_2,
                        ENTRANCE_PORT_DIAMETER_2=ENTRANCE_PORT_DIAMETER_2,
                        DETECTOR_PORT_DIAMETER_2=DETECTOR_PORT_DIAMETER_2,
                        WALL_REFLECTANCE=0, DETECTOR_REFLECTANCE=DETECTOR_REFLECTANCE, STANDARD_REFLECTANCE=0,
                        THETA=8, REFRACTIVE_INDEX_SAMPLE=1)
    for wave_idx, wave in enumerate(wavelength):
        sphere_R = SPHERE_R(SPHERE_DIAMETER=SPHERE_DIAMETER, SAMPLE_PORT_DIAMETER=SAMPLE_PORT_DIAMETER,
                            ENTRANCE_PORT_DIAMETER=ENTRANCE_PORT_DIAMETER,
                            DETECTOR_PORT_DIAMETER=DETECTOR_PORT_DIAMETER,
                            WALL_REFLECTANCE=rw_r_spline[wave_idx], DETECTOR_REFLECTANCE=DETECTOR_REFLECTANCE,
                            STANDARD_REFLECTANCE=C_99_nominal[wave_idx],
                            THETA=8, REFRACTIVE_INDEX_SAMPLE=1)
        R_white = sphere_R.Two_Sphere_R(sphere_T, C_99_nominal[wave_idx], C_99_nominal[wave_idx], 0, 0)
        P_20230606[wave_idx] = (R_ref[wave_idx] - R_open[wave_idx]) / R_white
    plt.figure("Input Power")
    plt.plot(wavelength, P_20230602, label="P_20230602")
    plt.plot(wavelength, P_20230606, label="P_20230606")
    plt.legend()

    """From T_air_meas, Work out rw_t"""
    as_t = (SAMPLE_PORT_DIAMETER_2 / SPHERE_DIAMETER_2) ** 2 / 4  # sample aperture
    ae_t = (ENTRANCE_PORT_DIAMETER_2 / SPHERE_DIAMETER_2) ** 2 / 4  # entrance aperture
    ad_t = (DETECTOR_PORT_DIAMETER_2 / SPHERE_DIAMETER_2) ** 2 / 4  # detector aperture
    aw_t = 1 - as_t - ae_t - ad_t
    T = T_air_meas / P_20230606
    rw_t_20230602 = T * (1 - aw_r * rw_r_20230602) / \
                    (T * (1 - aw_r * rw_r_20230602) * aw_t + T * as_r * as_t * rw_r_20230602 * (1 - ae_r) * (1 - ae_t) +
                     ad_t * (1 - ae_t) * (1 - aw_r * rw_r_20230602))
    rw_t_20230606 = T * (1 - aw_r * rw_r_spline) / \
                    (T * (1 - aw_r * rw_r_spline) * aw_t + T * as_r * as_t * rw_r_spline * (1 - ae_r) * (1 - ae_t) +
                     ad_t * (1 - ae_t) * (1 - aw_r * rw_r_spline))
    spl = UnivariateSpline(wavelength, rw_t_20230606, s=2e-6)
    rw_t_spline = spl(wavelength)
    plt.figure("rw")
    plt.plot(wavelength, rw_t_20230602, label="rw_t_20230602")
    plt.plot(wavelength, rw_t_20230606, label="rw_t_20230606")
    plt.plot(wavelength, rw_t_spline, label="Smooth rw_t_20230606")
    plt.legend()

    """Compare rw_r and rw_t"""
    plt.figure("Compare rw_r and rw_t")
    plt.plot(wavelength, rw_r_spline / np.amax(rw_r_spline), label="Normalised rw_r")
    plt.plot(wavelength, rw_t_spline / np.amax(rw_t_spline), label="Normalised rw_t")
    plt.legend()

    """Sanity Check of R and T"""
    R_white_sim = np.zeros_like(R_air_meas)
    R_air_sim = np.zeros_like(R_air_meas)
    T_air_sim = np.zeros_like(T_air_meas)
    for wave_idx, wave in enumerate(wavelength):
        sphere_R = SPHERE_R(SPHERE_DIAMETER=SPHERE_DIAMETER, SAMPLE_PORT_DIAMETER=SAMPLE_PORT_DIAMETER,
                            ENTRANCE_PORT_DIAMETER=ENTRANCE_PORT_DIAMETER,
                            DETECTOR_PORT_DIAMETER=DETECTOR_PORT_DIAMETER,
                            WALL_REFLECTANCE=rw_r_spline[wave_idx], DETECTOR_REFLECTANCE=DETECTOR_REFLECTANCE,
                            STANDARD_REFLECTANCE=C_99_nominal[wave_idx],
                            THETA=8, REFRACTIVE_INDEX_SAMPLE=1)
        sphere_T = SPHERE_T(SPHERE_DIAMETER_2=SPHERE_DIAMETER_2, SAMPLE_PORT_DIAMETER_2=SAMPLE_PORT_DIAMETER_2,
                            ENTRANCE_PORT_DIAMETER_2=ENTRANCE_PORT_DIAMETER_2,
                            DETECTOR_PORT_DIAMETER_2=DETECTOR_PORT_DIAMETER_2,
                            WALL_REFLECTANCE=rw_t_spline[wave_idx], DETECTOR_REFLECTANCE=DETECTOR_REFLECTANCE,
                            STANDARD_REFLECTANCE=0,
                            THETA=8, REFRACTIVE_INDEX_SAMPLE=1)
        R_air_sim[wave_idx] = P_20230606[wave_idx] * sphere_R.Two_Sphere_R(sphere_T, 0, 0, 1, 1)
        T_air_sim[wave_idx] = P_20230606[wave_idx] * sphere_T.Two_Sphere_T(sphere_R, 0, 0, 1, 1)
        R_white_sim[wave_idx] = P_20230606[wave_idx] * sphere_R.Two_Sphere_R(sphere_T, C_99_nominal[wave_idx], C_99_nominal[wave_idx], 0, 0)

    plt.figure("Air")
    plt.plot(wavelength, T_air_sim, label="T_air_sim")
    plt.plot(wavelength, R_air_sim, label="R_air_sim")
    plt.legend()

    plt.figure("R_white")
    plt.plot(wavelength, R_ref - R_open, label="R_white_meas")
    plt.plot(wavelength, R_white_sim, label="R_white_sim")
    plt.legend()

    """Sanity Check of M_R"""
    M_R_air_meas = C_99_nominal * R_air_meas / (R_ref - R_open)
    M_R_air_sim = np.zeros_like(M_R_air_meas)
    M_T_air_sim = np.zeros_like(M_R_air_meas)
    for wave_idx, wave in enumerate(wavelength):
        M_R_air_sim[wave_idx], M_T_air_sim[wave_idx] = correct_spheres(0, 1, 0, 0, 0, 1,
                                                                       8, C_99_nominal[wave_idx], 1,
                                                                       rw_r_spline[wave_idx], rw_t_spline[wave_idx],
                                                                       0,
                                                                       SPHERE_DIAMETER, SAMPLE_PORT_DIAMETER,
                                                                       ENTRANCE_PORT_DIAMETER=ENTRANCE_PORT_DIAMETER,
                                                                       DETECTOR_PORT_DIAMETER=DETECTOR_PORT_DIAMETER)
    # compare with 0.985 rw
    M_R_air_985 = np.zeros_like(M_R_air_meas)
    M_T_air_985 = np.zeros_like(M_R_air_meas)
    for wave_idx, wave in enumerate(wavelength):
        M_R_air_985[wave_idx], M_T_air_985[wave_idx] = correct_spheres(0, 1, 0, 0, 0, 1,
                                                                       8, C_99_nominal[wave_idx], 1,
                                                                       0.985, 0.985,
                                                                       0,
                                                                       SPHERE_DIAMETER, SAMPLE_PORT_DIAMETER,
                                                                       ENTRANCE_PORT_DIAMETER=ENTRANCE_PORT_DIAMETER,
                                                                       DETECTOR_PORT_DIAMETER=DETECTOR_PORT_DIAMETER)
    plt.figure("M_R")
    plt.plot(wavelength, M_R_air_meas, label="Measured")
    plt.plot(wavelength, M_R_air_sim,
             label="Simulated with\n"+r'$\mathrm{Estimated}\;r_w\;r_w^{\prime}$')
    plt.plot(wavelength, M_R_air_985,
             label="Simulated with\n"+r'$r_w=r_w^{\prime}=0.985$')
    plt.legend()
    plt.xlabel("Wavelength (nm)")
    plt.ylabel(r'$M_R \; \mathrm{(a.u.)}$')

    # plt.figure("M_T")
    # plt.plot(wavelength, M_T_air_sim, label="M_T_air_sim")

    """Plot rw"""
    plt.figure("rw plot")
    plt.plot(wavelength, rw_r_20230606, label=r'$r_w$')
    plt.plot(wavelength, rw_r_spline, label="Smoothed "+r'$r_w$')
    plt.plot(wavelength, rw_t_20230606, label=r'$r_w^{\prime}$')
    plt.plot(wavelength, rw_t_spline, label="Smoothed "+r'$r_w^{\prime}$')
    plt.legend()
    plt.xlabel("Wavelength (nm)")
    plt.ylabel("Wall Reflectance (a.u.)")

    plt.show()
    #
    # np.save("rw_r_20230606", rw_r_spline)
    # np.save("rw_t_20230606", rw_t_spline)
