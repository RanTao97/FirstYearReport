# this is to run IAD on dataset of A2, B3, B7, C5, D7

import numpy as np
import matplotlib.pyplot as plt
import os.path
import subprocess

# set figure size and font size
plt.rcParams['figure.autolayout'] = True
plt.rcParams['axes.titlesize'] = 'x-large'
plt.rcParams['axes.labelsize'] = 'large'
plt.rcParams['xtick.labelsize'] = 'large'
plt.rcParams['ytick.labelsize'] = 'large'
plt.rcParams['legend.fontsize'] = 'large'

PATH_NoTape = "20230616_IAD/NoTape"
PATH_BlackTape = "20230616_IAD/BlackTape"
PATH_IADResults = "20230616_IAD"

PATH_C_99 = "D:/OneDrive - University of Cambridge/Integrating Sphere Calibration Standards/SRS-99-020/SRS-99-020.txt"
PATH_rw_r = "rw_r_20230606.npy"
PATH_rw_t = "rw_t_20230606.npy"
rw_wave = np.arange(450, 951, 1)

BEAM_DIAMETER = 8.0
SPHERE_DIAMETER=50
SAMPLE_PORT_DIAMETER=10
ENTRANCE_PORT_DIAMETER=4.9
DETECTOR_PORT_DIAMETER=0.2
DETECTOR_REFLECTANCE=0

SPHERE_DIAMETER_2=SPHERE_DIAMETER
SAMPLE_PORT_DIAMETER_2=SAMPLE_PORT_DIAMETER
ENTRANCE_PORT_DIAMETER_2=0
DETECTOR_PORT_DIAMETER_2=DETECTOR_PORT_DIAMETER


def run_iad(path, path_rxt, wavelength, rw=False, thickness_squeeze=False):
    """
    this is to run iad
    :param path: path to measured data
    :param path_rxt: path to .rxt folder
    :param wavelength: wavelength measured
    :param rw: False: use 0.985; True: use rw
    :param thickness_squeeze: True: squeeze; False: not squeeze
    :return: nothing
    """
    """Read Calibration Standard 99%: Nominal Data"""
    C_lambda = np.loadtxt(PATH_C_99, skiprows=2, usecols=0)  # calibration wavelength
    C_99_nominal = np.loadtxt(PATH_C_99, skiprows=2, usecols=1)  # calibration values
    C_99_nominal = np.interp(wavelength, C_lambda, C_99_nominal)  # interpolated calibration values

    """Read Measured Data"""
    wavelength_all = np.loadtxt(path + "/1_R_OpenPort.txt", usecols=0)
    R_open = np.loadtxt(path + "/1_R_OpenPort.txt", usecols=1)
    R_ref = np.loadtxt(path + "/1_R_RefInPlace.txt", usecols=1)
    T_block = np.loadtxt(path + "/1_T_BlockBeam.txt", usecols=1)
    T_inc = np.loadtxt(path + "/1_T_IncBeam.txt", usecols=1)

    R_B = np.loadtxt(path + "/B/1_R_SampInPlace.txt", usecols=1)
    T_B = np.loadtxt(path + "/B/1_T_SampInPlace.txt", usecols=1)
    M_R_B = C_99_nominal * np.interp(wavelength, wavelength_all, (R_B - R_open) / (R_ref - R_open))
    M_T_B = np.interp(wavelength, wavelength_all, (T_B - T_block) / (T_inc - T_block))

    R_T = np.loadtxt(path + "/T/1_R_SampInPlace.txt", usecols=1)
    T_T = np.loadtxt(path + "/T/1_T_SampInPlace.txt", usecols=1)
    M_R_T = C_99_nominal * np.interp(wavelength, wavelength_all, (R_T - R_open) / (R_ref - R_open))
    M_T_T = np.interp(wavelength, wavelength_all, (T_T - T_block) / (T_inc - T_block))

    """generate .rxt"""
    if not rw:
        rw_r = 0.985 * np.ones_like(wavelength)
        rw_t = 0.985 * np.ones_like(wavelength)
        if thickness_squeeze:
            thickness_B = np.mean(np.loadtxt(path + "/B/thickness-.txt"))
            thickness_T = np.mean(np.loadtxt(path + "/T/thickness-.txt"))
        else:
            thickness_B = np.mean(np.loadtxt(path + "/B/thickness+.txt"))
            thickness_T = np.mean(np.loadtxt(path + "/T/thickness+.txt"))
    if rw:
        rw_r = np.interp(wavelength, rw_wave, np.load(PATH_rw_r))
        rw_t = np.interp(wavelength, rw_wave, np.load(PATH_rw_t))
        if thickness_squeeze:
            thickness_B = np.mean(np.loadtxt(path + "/B/thickness-.txt"))
            thickness_T = np.mean(np.loadtxt(path + "/T/thickness-.txt"))
        else:
            thickness_B = np.mean(np.loadtxt(path + "/B/thickness+.txt"))
            thickness_T = np.mean(np.loadtxt(path + "/T/thickness+.txt"))

    path_rxt_B = path_rxt + "/B.rxt"
    path_rxt_T = path_rxt + "/T.rxt"
    with open(path_rxt_B, "w") as rxt_file:
        rxt_file.writelines(f"IAD1   # Must be first four characters\n\n"
                            f"# The order of entries is important\n"
                            f"# Anything after a '#' is ignored, blank lines are also ignored\n\n"
                            f'{1.41:.6f}\t# Index of refraction of the sample\n'
                            f'{1.5:.6f}\t# Index of refraction of the top and bottom slides\n'
                            f'{thickness_B:.6f}\t# [mm] Thickness of sample\n'
                            f'{0.0:.6f}\t# [mm] Thickness of slides\n'
                            f'{BEAM_DIAMETER:.6f}\t# [mm] Diameter of illumination beam\n'
                            f'{0.0:.6f}\t# [mm] Reflectance of the calibration standard, Change Later\n'
                            f'{2:.2f}\t# Number of spheres used during each measurement\n\n'
                            f'# Properties of sphere used for reflection measurements\n'
                            f'{SPHERE_DIAMETER:.6f}\t# [mm] Sphere Diameter\n'
                            f'{SAMPLE_PORT_DIAMETER:.6f}\t# [mm] Sample Port Diameter\n'
                            f'{ENTRANCE_PORT_DIAMETER:.6f}\t# [mm] Entrance Port Diameter\n'
                            f'{DETECTOR_PORT_DIAMETER:.6f}\t# [mm] Detector Port Diameter\n'
                            f'{0.0:.6f}\t# Reflectivity of the sphere wall, Change Later\n\n'
                            f"# Properties of sphere used for transmission measurements\n"
                            f'{SPHERE_DIAMETER_2:.6f}\t# [mm] Sphere Diameter\n'
                            f'{SAMPLE_PORT_DIAMETER_2:.6f}\t# [mm] Sample Port Diameter\n'
                            f'{ENTRANCE_PORT_DIAMETER_2:.6f}\t# [mm] Entrance Port Diameter\n'
                            f'{DETECTOR_PORT_DIAMETER_2:.6f}\t# [mm] Detector Port Diameter\n'
                            f'{0.0:.6f}\t# Reflectivity of the sphere wall, Change Later\n\n'
                            f"6.000000\t# Number of measurements, M_R, M_T, M_U, r_w, t_w, r_std\n\n"
                            f"#lambda\t\tM_R\t\tM_T\t\tM_U\t\tr_w\t\tt_w\t\tr_std\n")
        for wavelength_idx, wavelength_val in enumerate(wavelength):
            rxt_file.writelines(f"{wavelength_val}\t\t{M_R_B[wavelength_idx]:.9f}\t{M_T_B[wavelength_idx]:.9f}\t"
                                f"{0.0:.9f}\t"
                                f"{rw_r[wavelength_idx]:.9f}\t{rw_t[wavelength_idx]:.9f}\t"
                                f"{C_99_nominal[wavelength_idx]:.9f}\n")
    rxt_file.close()
    with open(path_rxt_T, "w") as rxt_file:
        rxt_file.writelines(f"IAD1   # Must be first four characters\n\n"
                            f"# The order of entries is important\n"
                            f"# Anything after a '#' is ignored, blank lines are also ignored\n\n"
                            f'{1.41:.6f}\t# Index of refraction of the sample\n'
                            f'{1.5:.6f}\t# Index of refraction of the top and bottom slides\n'
                            f'{thickness_T:.6f}\t# [mm] Thickness of sample\n'
                            f'{0.0:.6f}\t# [mm] Thickness of slides\n'
                            f'{BEAM_DIAMETER:.6f}\t# [mm] Diameter of illumination beam\n'
                            f'{0.0:.6f}\t# [mm] Reflectance of the calibration standard, Change Later\n'
                            f'{2:.2f}\t# Number of spheres used during each measurement\n\n'
                            f'# Properties of sphere used for reflection measurements\n'
                            f'{SPHERE_DIAMETER:.6f}\t# [mm] Sphere Diameter\n'
                            f'{SAMPLE_PORT_DIAMETER:.6f}\t# [mm] Sample Port Diameter\n'
                            f'{ENTRANCE_PORT_DIAMETER:.6f}\t# [mm] Entrance Port Diameter\n'
                            f'{DETECTOR_PORT_DIAMETER:.6f}\t# [mm] Detector Port Diameter\n'
                            f'{0.0:.6f}\t# Reflectivity of the sphere wall, Change Later\n\n'
                            f"# Properties of sphere used for transmission measurements\n"
                            f'{SPHERE_DIAMETER_2:.6f}\t# [mm] Sphere Diameter\n'
                            f'{SAMPLE_PORT_DIAMETER_2:.6f}\t# [mm] Sample Port Diameter\n'
                            f'{ENTRANCE_PORT_DIAMETER_2:.6f}\t# [mm] Entrance Port Diameter\n'
                            f'{DETECTOR_PORT_DIAMETER_2:.6f}\t# [mm] Detector Port Diameter\n'
                            f'{0.0:.6f}\t# Reflectivity of the sphere wall, Change Later\n\n'
                            f"6.000000\t# Number of measurements, M_R, M_T, M_U, r_w, t_w, r_std\n\n"
                            f"#lambda\t\tM_R\t\tM_T\t\tM_U\t\tr_w\t\tt_w\t\tr_std\n")
        for wavelength_idx, wavelength_val in enumerate(wavelength):
            rxt_file.writelines(f"{wavelength_val}\t\t{M_R_T[wavelength_idx]:.9f}\t{M_T_T[wavelength_idx]:.9f}\t"
                                f"{0.0:.9f}\t"
                                f"{rw_r[wavelength_idx]:.9f}\t{rw_t[wavelength_idx]:.9f}\t"
                                f"{C_99_nominal[wavelength_idx]:.9f}\n")
    rxt_file.close()

    """Run IAD"""
    print("Starting IAD program: B")
    cmd = list()
    cmd.append("D:/OneDrive - University of Cambridge/IAD-win-3-11-4/iad.exe")
    cmd.append("-q 12")  # number of quadrature points (default=8)
    cmd.append(f'-i 8')  # light is incident at this angle in degrees
    cmd.append(f'-g 0.7')  # fixed scattering anisotropy (default 0)
    cmd.append(path_rxt_B)
    subprocess.run(cmd)
    print("Starting IAD program: T")
    cmd = list()
    cmd.append("D:/OneDrive - University of Cambridge/IAD-win-3-11-4/iad.exe")
    cmd.append("-q 12")  # number of quadrature points (default=8)
    cmd.append(f'-i 8')  # light is incident at this angle in degrees
    cmd.append(f'-g 0.7')  # fixed scattering anisotropy (default 0)
    cmd.append(path_rxt_T)
    subprocess.run(cmd)

class BioPixSDatasheet:
    def __init__(self, wave, mu_a_true, mu_sp_true):
        self.wave = wave
        self.mu_a_true = 0.1 * mu_a_true  # convert to [mm-1]
        self.mu_sp_true = 0.1 * mu_sp_true  # convert to [mm-1]

class Sample:
    def __init__(self, wave, mu_a_true, mu_sp_true, name):
        self.wave = wave
        self.mu_a_true = 0.1 * mu_a_true  # convert to [mm-1]
        self.mu_sp_true = 0.1 * mu_sp_true  # convert to [mm-1]
        self.name = name  # sample name

        # DIS measurement results
        self.wavelength = None
        self.thickness = None
        self.mu_a_est = None
        self.mu_sp_est = None

    def read_txt(self, path):
        """
            this is to read .txt
            :param path: path to IAD result folder
            :return: mu_a_est [mm-1], mu_sp_est [mm-1], error_code
        """
        # only read T.txt
        path_B_txt = path + "/T.txt"
        path_B_rxt = path + "/T.rxt"
        self.wavelength = np.loadtxt(path_B_txt, comments='#', usecols=0)
        self.thickness = np.loadtxt(path_B_rxt, comments='#', skiprows=7, max_rows=1)

        self.mu_a_est = np.loadtxt(path_B_txt, comments='#', usecols=5)
        self.mu_sp_est = np.loadtxt(path_B_txt, comments='#', usecols=6)


if __name__ == '__main__':
    B2_BioPixS = BioPixSDatasheet(wave=np.array([500, 600, 780, 900]),
                                  mu_a_true=np.array([0.06, 0.06, 0.05, 0.11]),
                                  mu_sp_true=np.array([14.7, 13.2, 10.2, 8.2]))
    C2_BioPixS = BioPixSDatasheet(wave=np.array([600, 780]), mu_a_true=np.array([0.06, 0.05]),
                                  mu_sp_true=np.array([19.7, 15]))
    C3_BioPixS = BioPixSDatasheet(wave=np.array([600, 780]), mu_a_true=np.array([0.12, 0.1]),
                                  mu_sp_true=np.array([19.8, 15.2]))

    """IAD Already Run in run_IAD.py"""

    """B2"""
    B2_d1 = Sample(wave=np.array([500, 600, 780, 900]),
                mu_a_true=np.array([0.06, 0.06, 0.05, 0.11]), mu_sp_true=np.array([14.7, 13.2, 10.2, 8.2]),
                name="BioPixS_B2_d1")
    B2_d1.read_txt("20230616_IAD/BlackTape_rw_thickness-/BioPixS_B2_2")
    B2_d2 = Sample(wave=np.array([500, 600, 780, 900]),
                   mu_a_true=np.array([0.06, 0.06, 0.05, 0.11]), mu_sp_true=np.array([14.7, 13.2, 10.2, 8.2]),
                   name="BioPixS_B2_d2")
    B2_d2.read_txt("20230616_IAD/BlackTape_rw_thickness-/BioPixS_B2")
    B2_d3 = Sample(wave=np.array([500, 600, 780, 900]),
                   mu_a_true=np.array([0.06, 0.06, 0.05, 0.11]), mu_sp_true=np.array([14.7, 13.2, 10.2, 8.2]),
                   name="BioPixS_B2_d3")
    B2_d3.read_txt("20230616_IAD/BlackTape_rw_thickness+/BioPixS_B2_2")
    B2_d4 = Sample(wave=np.array([500, 600, 780, 900]),
                   mu_a_true=np.array([0.06, 0.06, 0.05, 0.11]), mu_sp_true=np.array([14.7, 13.2, 10.2, 8.2]),
                   name="BioPixS_B2_d4")
    B2_d4.read_txt("20230616_IAD/BlackTape_rw_thickness+/BioPixS_B2")

    plt.figure("B2 mu_a")
    plt.plot(B2_BioPixS.wave, B2_BioPixS.mu_a_true, c='k')
    plt.scatter(B2_d1.wavelength, B2_d1.mu_a_est, label=f"{B2_d1.thickness:.2f} mm")
    plt.scatter(B2_d2.wavelength, B2_d2.mu_a_est, label=f"{B2_d2.thickness:.2f} mm")
    plt.scatter(B2_d3.wavelength, B2_d3.mu_a_est, label=f"{B2_d3.thickness:.2f} mm")
    plt.scatter(B2_d4.wavelength, B2_d4.mu_a_est, label=f"{B2_d4.thickness:.2f} mm")
    plt.legend()

    plt.figure("B2 mu_sp")
    plt.plot(B2_BioPixS.wave, B2_BioPixS.mu_sp_true, c='k')
    plt.scatter(B2_d1.wavelength, B2_d1.mu_sp_est, label=f"{B2_d1.thickness:.2f} mm")
    plt.scatter(B2_d2.wavelength, B2_d2.mu_sp_est, label=f"{B2_d2.thickness:.2f} mm")
    plt.scatter(B2_d3.wavelength, B2_d3.mu_sp_est, label=f"{B2_d3.thickness:.2f} mm")
    plt.scatter(B2_d4.wavelength, B2_d4.mu_sp_est, label=f"{B2_d4.thickness:.2f} mm")
    plt.legend()

    """C2"""
    C2_d1 = Sample(wave=np.array([600, 780]), mu_a_true=np.array([0.06, 0.05]), mu_sp_true=np.array([19.7, 15]),
                   name="BioPixS_C2_d1")
    C2_d1.read_txt("20230616_IAD/BlackTape_rw_thickness-/BioPixS_C2_2")
    C2_d2 = Sample(wave=np.array([600, 780]), mu_a_true=np.array([0.06, 0.05]), mu_sp_true=np.array([19.7, 15]),
                   name="BioPixS_C2_d2")
    C2_d2.read_txt("20230616_IAD/BlackTape_rw_thickness-/BioPixS_C2")
    C2_d3 = Sample(wave=np.array([600, 780]), mu_a_true=np.array([0.06, 0.05]), mu_sp_true=np.array([19.7, 15]),
                   name="BioPixS_C2_d3")
    C2_d3.read_txt("20230616_IAD/BlackTape_rw_thickness+/BioPixS_C2_2")
    C2_d4 = Sample(wave=np.array([600, 780]), mu_a_true=np.array([0.06, 0.05]), mu_sp_true=np.array([19.7, 15]),
                   name="BioPixS_C2_d4")
    C2_d4.read_txt("20230616_IAD/BlackTape_rw_thickness+/BioPixS_C2")

    plt.figure("C2 mu_a")
    plt.plot(C2_BioPixS.wave, C2_BioPixS.mu_a_true, c='k')
    plt.scatter(C2_d1.wavelength, C2_d1.mu_a_est, label=f"{C2_d1.thickness:.2f} mm")
    plt.scatter(C2_d2.wavelength, C2_d2.mu_a_est, label=f"{C2_d2.thickness:.2f} mm")
    plt.scatter(C2_d3.wavelength, C2_d3.mu_a_est, label=f"{C2_d3.thickness:.2f} mm")
    plt.scatter(C2_d4.wavelength, C2_d4.mu_a_est, label=f"{C2_d4.thickness:.2f} mm")
    plt.legend()

    plt.figure("C2 mu_sp")
    plt.plot(C2_BioPixS.wave, C2_BioPixS.mu_sp_true, c='k')
    plt.scatter(C2_d1.wavelength, C2_d1.mu_sp_est, label=f"{C2_d1.thickness:.2f} mm")
    plt.scatter(C2_d2.wavelength, C2_d2.mu_sp_est, label=f"{C2_d2.thickness:.2f} mm")
    plt.scatter(C2_d3.wavelength, C2_d3.mu_sp_est, label=f"{C2_d3.thickness:.2f} mm")
    plt.scatter(C2_d4.wavelength, C2_d4.mu_sp_est, label=f"{C2_d4.thickness:.2f} mm")
    plt.legend()

    """C3"""
    C3_d1 = Sample(wave=np.array([600, 780]), mu_a_true=np.array([0.12, 0.1]), mu_sp_true=np.array([19.8, 15.2]),
                   name="BioPixS_C3_d1")
    C3_d1.read_txt("20230616_IAD/BlackTape_rw_thickness-/BioPixS_C3_2")
    C3_d2 = Sample(wave=np.array([600, 780]), mu_a_true=np.array([0.12, 0.1]), mu_sp_true=np.array([19.8, 15.2]),
                   name="BioPixS_C3_d2")
    C3_d2.read_txt("20230616_IAD/BlackTape_rw_thickness-/BioPixS_C3")
    C3_d3 = Sample(wave=np.array([600, 780]), mu_a_true=np.array([0.12, 0.1]), mu_sp_true=np.array([19.8, 15.2]),
                   name="BioPixS_C3_d3")
    C3_d3.read_txt("20230616_IAD/BlackTape_rw_thickness+/BioPixS_C3_2")
    C3_d4 = Sample(wave=np.array([600, 780]), mu_a_true=np.array([0.12, 0.1]), mu_sp_true=np.array([19.8, 15.2]),
                   name="BioPixS_C3_d4")
    C3_d4.read_txt("20230616_IAD/BlackTape_rw_thickness+/BioPixS_C3")

    plt.figure("C3 mu_a")
    plt.plot(C3_BioPixS.wave, C3_BioPixS.mu_a_true, c='k')
    plt.scatter(C3_d1.wavelength, C3_d1.mu_a_est, label=f"{C3_d1.thickness:.2f} mm")
    plt.scatter(C3_d2.wavelength, C3_d2.mu_a_est, label=f"{C3_d2.thickness:.2f} mm")
    plt.scatter(C3_d3.wavelength, C3_d3.mu_a_est, label=f"{C3_d3.thickness:.2f} mm")
    plt.scatter(C3_d4.wavelength, C3_d4.mu_a_est, label=f"{C3_d4.thickness:.2f} mm")
    plt.legend()

    plt.figure("C3 780 nm mu_a v.s. thickness")
    plt.axhline(C3_BioPixS.mu_a_true[1], c='k', label="True Value")
    plt.scatter(C3_d1.thickness, C3_d1.mu_a_est[1])
    plt.scatter(C3_d2.thickness, C3_d2.mu_a_est[1])
    plt.scatter(C3_d3.thickness, C3_d3.mu_a_est[1])
    plt.scatter(C3_d4.thickness, C3_d4.mu_a_est[1])
    plt.legend()
    plt.xlabel("Thickness d (mm)")
    plt.ylabel(r'$\mathrm{Estimated} \; \mu_a \; \mathrm{(mm^{-1})}$')
    print((C3_d1.mu_a_est[1] - C3_d4.mu_a_est[1]) / C3_BioPixS.mu_a_true[1] * 100)

    plt.figure("C3 mu_sp")
    plt.plot(C3_BioPixS.wave, C3_BioPixS.mu_sp_true, c='k')
    plt.scatter(C3_d1.wavelength, C3_d1.mu_sp_est, label=f"{C3_d1.thickness:.2f} mm")
    plt.scatter(C3_d2.wavelength, C3_d2.mu_sp_est, label=f"{C3_d2.thickness:.2f} mm")
    plt.scatter(C3_d3.wavelength, C3_d3.mu_sp_est, label=f"{C3_d3.thickness:.2f} mm")
    plt.scatter(C3_d4.wavelength, C3_d4.mu_sp_est, label=f"{C3_d4.thickness:.2f} mm")
    plt.legend()

    plt.figure("C3 780 nm mu_sp v.s. thickness")
    plt.axhline(C3_BioPixS.mu_sp_true[1], c='k', label="True Value")
    plt.scatter(C3_d1.thickness, C3_d1.mu_sp_est[1])
    plt.scatter(C3_d2.thickness, C3_d2.mu_sp_est[1])
    plt.scatter(C3_d3.thickness, C3_d3.mu_sp_est[1])
    plt.scatter(C3_d4.thickness, C3_d4.mu_sp_est[1])
    plt.legend()
    plt.xlabel("Thickness d (mm)")
    plt.ylabel(r'$\mathrm{Estimated} \; \mu_s^{\prime} \; \mathrm{(mm^{-1})}$')
    print((C3_d1.mu_sp_est[1] - C3_d4.mu_sp_est[1])/ C3_BioPixS.mu_sp_true[1] *100)

    plt.show()