# this is to run IAD on dataset of A2, B3, B7, C5, D7

import numpy as np
import matplotlib.pyplot as plt
import os.path
import subprocess

# set figure size and font size
plt.rcParams['figure.autolayout'] = True
plt.rcParams['figure.figsize'] = (6.4, 5.2)
plt.rcParams['axes.titlesize'] = 'x-large'
plt.rcParams['axes.labelsize'] = 'large'
plt.rcParams['xtick.labelsize'] = 'large'
plt.rcParams['ytick.labelsize'] = 'large'
plt.rcParams['legend.fontsize'] = 'large'

PATH_NoTape = "20230616_IAD/NoTape"
PATH_BlackTape = "20230616_IAD/BlackTape"
PATH_IADResults = "20230616_IAD"

PATH_C_99 = "D:/OneDrive - University of Cambridge/Integrating Sphere Calibration Standards/SRS-99-020/SRS-99-020.txt"
PATH_rw_r = "rw_r_20230606.npy"
PATH_rw_t = "rw_t_20230606.npy"
rw_wave = np.arange(450, 951, 1)

BEAM_DIAMETER = 8.0
SPHERE_DIAMETER=50
SAMPLE_PORT_DIAMETER=10
ENTRANCE_PORT_DIAMETER=4.9
DETECTOR_PORT_DIAMETER=0.2
DETECTOR_REFLECTANCE=0

SPHERE_DIAMETER_2=SPHERE_DIAMETER
SAMPLE_PORT_DIAMETER_2=SAMPLE_PORT_DIAMETER
ENTRANCE_PORT_DIAMETER_2=0
DETECTOR_PORT_DIAMETER_2=DETECTOR_PORT_DIAMETER


def run_iad(path, path_rxt, wavelength, rw=False, thickness_squeeze=False):
    """
    this is to run iad
    :param path: path to measured data
    :param path_rxt: path to .rxt folder
    :param wavelength: wavelength measured
    :param rw: False: use 0.985; True: use rw
    :param thickness_squeeze: True: squeeze; False: not squeeze
    :return: nothing
    """
    """Read Calibration Standard 99%: Nominal Data"""
    C_lambda = np.loadtxt(PATH_C_99, skiprows=2, usecols=0)  # calibration wavelength
    C_99_nominal = np.loadtxt(PATH_C_99, skiprows=2, usecols=1)  # calibration values
    C_99_nominal = np.interp(wavelength, C_lambda, C_99_nominal)  # interpolated calibration values

    """Read Measured Data"""
    wavelength_all = np.loadtxt(path + "/1_R_OpenPort.txt", usecols=0)
    R_open = np.loadtxt(path + "/1_R_OpenPort.txt", usecols=1)
    R_ref = np.loadtxt(path + "/1_R_RefInPlace.txt", usecols=1)
    T_block = np.loadtxt(path + "/1_T_BlockBeam.txt", usecols=1)
    T_inc = np.loadtxt(path + "/1_T_IncBeam.txt", usecols=1)

    R_B = np.loadtxt(path + "/B/1_R_SampInPlace.txt", usecols=1)
    T_B = np.loadtxt(path + "/B/1_T_SampInPlace.txt", usecols=1)
    M_R_B = C_99_nominal * np.interp(wavelength, wavelength_all, (R_B - R_open) / (R_ref - R_open))
    M_T_B = np.interp(wavelength, wavelength_all, (T_B - T_block) / (T_inc - T_block))

    R_T = np.loadtxt(path + "/T/1_R_SampInPlace.txt", usecols=1)
    T_T = np.loadtxt(path + "/T/1_T_SampInPlace.txt", usecols=1)
    M_R_T = C_99_nominal * np.interp(wavelength, wavelength_all, (R_T - R_open) / (R_ref - R_open))
    M_T_T = np.interp(wavelength, wavelength_all, (T_T - T_block) / (T_inc - T_block))

    """generate .rxt"""
    if not rw:
        rw_r = 0.985 * np.ones_like(wavelength)
        rw_t = 0.985 * np.ones_like(wavelength)
        if thickness_squeeze:
            thickness_B = np.mean(np.loadtxt(path + "/B/thickness-.txt"))
            thickness_T = np.mean(np.loadtxt(path + "/T/thickness-.txt"))
        else:
            thickness_B = np.mean(np.loadtxt(path + "/B/thickness+.txt"))
            thickness_T = np.mean(np.loadtxt(path + "/T/thickness+.txt"))
    if rw:
        rw_r = np.interp(wavelength, rw_wave, np.load(PATH_rw_r))
        rw_t = np.interp(wavelength, rw_wave, np.load(PATH_rw_t))
        if thickness_squeeze:
            thickness_B = np.mean(np.loadtxt(path + "/B/thickness-.txt"))
            thickness_T = np.mean(np.loadtxt(path + "/T/thickness-.txt"))
        else:
            thickness_B = np.mean(np.loadtxt(path + "/B/thickness+.txt"))
            thickness_T = np.mean(np.loadtxt(path + "/T/thickness+.txt"))

    path_rxt_B = path_rxt + "/B.rxt"
    path_rxt_T = path_rxt + "/T.rxt"
    with open(path_rxt_B, "w") as rxt_file:
        rxt_file.writelines(f"IAD1   # Must be first four characters\n\n"
                            f"# The order of entries is important\n"
                            f"# Anything after a '#' is ignored, blank lines are also ignored\n\n"
                            f'{1.41:.6f}\t# Index of refraction of the sample\n'
                            f'{1.5:.6f}\t# Index of refraction of the top and bottom slides\n'
                            f'{thickness_B:.6f}\t# [mm] Thickness of sample\n'
                            f'{0.0:.6f}\t# [mm] Thickness of slides\n'
                            f'{BEAM_DIAMETER:.6f}\t# [mm] Diameter of illumination beam\n'
                            f'{0.0:.6f}\t# [mm] Reflectance of the calibration standard, Change Later\n'
                            f'{2:.2f}\t# Number of spheres used during each measurement\n\n'
                            f'# Properties of sphere used for reflection measurements\n'
                            f'{SPHERE_DIAMETER:.6f}\t# [mm] Sphere Diameter\n'
                            f'{SAMPLE_PORT_DIAMETER:.6f}\t# [mm] Sample Port Diameter\n'
                            f'{ENTRANCE_PORT_DIAMETER:.6f}\t# [mm] Entrance Port Diameter\n'
                            f'{DETECTOR_PORT_DIAMETER:.6f}\t# [mm] Detector Port Diameter\n'
                            f'{0.0:.6f}\t# Reflectivity of the sphere wall, Change Later\n\n'
                            f"# Properties of sphere used for transmission measurements\n"
                            f'{SPHERE_DIAMETER_2:.6f}\t# [mm] Sphere Diameter\n'
                            f'{SAMPLE_PORT_DIAMETER_2:.6f}\t# [mm] Sample Port Diameter\n'
                            f'{ENTRANCE_PORT_DIAMETER_2:.6f}\t# [mm] Entrance Port Diameter\n'
                            f'{DETECTOR_PORT_DIAMETER_2:.6f}\t# [mm] Detector Port Diameter\n'
                            f'{0.0:.6f}\t# Reflectivity of the sphere wall, Change Later\n\n'
                            f"6.000000\t# Number of measurements, M_R, M_T, M_U, r_w, t_w, r_std\n\n"
                            f"#lambda\t\tM_R\t\tM_T\t\tM_U\t\tr_w\t\tt_w\t\tr_std\n")
        for wavelength_idx, wavelength_val in enumerate(wavelength):
            rxt_file.writelines(f"{wavelength_val}\t\t{M_R_B[wavelength_idx]:.9f}\t{M_T_B[wavelength_idx]:.9f}\t"
                                f"{0.0:.9f}\t"
                                f"{rw_r[wavelength_idx]:.9f}\t{rw_t[wavelength_idx]:.9f}\t"
                                f"{C_99_nominal[wavelength_idx]:.9f}\n")
    rxt_file.close()
    with open(path_rxt_T, "w") as rxt_file:
        rxt_file.writelines(f"IAD1   # Must be first four characters\n\n"
                            f"# The order of entries is important\n"
                            f"# Anything after a '#' is ignored, blank lines are also ignored\n\n"
                            f'{1.41:.6f}\t# Index of refraction of the sample\n'
                            f'{1.5:.6f}\t# Index of refraction of the top and bottom slides\n'
                            f'{thickness_T:.6f}\t# [mm] Thickness of sample\n'
                            f'{0.0:.6f}\t# [mm] Thickness of slides\n'
                            f'{BEAM_DIAMETER:.6f}\t# [mm] Diameter of illumination beam\n'
                            f'{0.0:.6f}\t# [mm] Reflectance of the calibration standard, Change Later\n'
                            f'{2:.2f}\t# Number of spheres used during each measurement\n\n'
                            f'# Properties of sphere used for reflection measurements\n'
                            f'{SPHERE_DIAMETER:.6f}\t# [mm] Sphere Diameter\n'
                            f'{SAMPLE_PORT_DIAMETER:.6f}\t# [mm] Sample Port Diameter\n'
                            f'{ENTRANCE_PORT_DIAMETER:.6f}\t# [mm] Entrance Port Diameter\n'
                            f'{DETECTOR_PORT_DIAMETER:.6f}\t# [mm] Detector Port Diameter\n'
                            f'{0.0:.6f}\t# Reflectivity of the sphere wall, Change Later\n\n'
                            f"# Properties of sphere used for transmission measurements\n"
                            f'{SPHERE_DIAMETER_2:.6f}\t# [mm] Sphere Diameter\n'
                            f'{SAMPLE_PORT_DIAMETER_2:.6f}\t# [mm] Sample Port Diameter\n'
                            f'{ENTRANCE_PORT_DIAMETER_2:.6f}\t# [mm] Entrance Port Diameter\n'
                            f'{DETECTOR_PORT_DIAMETER_2:.6f}\t# [mm] Detector Port Diameter\n'
                            f'{0.0:.6f}\t# Reflectivity of the sphere wall, Change Later\n\n'
                            f"6.000000\t# Number of measurements, M_R, M_T, M_U, r_w, t_w, r_std\n\n"
                            f"#lambda\t\tM_R\t\tM_T\t\tM_U\t\tr_w\t\tt_w\t\tr_std\n")
        for wavelength_idx, wavelength_val in enumerate(wavelength):
            rxt_file.writelines(f"{wavelength_val}\t\t{M_R_T[wavelength_idx]:.9f}\t{M_T_T[wavelength_idx]:.9f}\t"
                                f"{0.0:.9f}\t"
                                f"{rw_r[wavelength_idx]:.9f}\t{rw_t[wavelength_idx]:.9f}\t"
                                f"{C_99_nominal[wavelength_idx]:.9f}\n")
    rxt_file.close()

    """Run IAD"""
    print("Starting IAD program: B")
    cmd = list()
    cmd.append("D:/OneDrive - University of Cambridge/IAD-win-3-11-4/iad.exe")
    cmd.append("-q 12")  # number of quadrature points (default=8)
    cmd.append(f'-i 8')  # light is incident at this angle in degrees
    cmd.append(f'-g 0.7')  # fixed scattering anisotropy (default 0)
    cmd.append(path_rxt_B)
    subprocess.run(cmd)
    print("Starting IAD program: T")
    cmd = list()
    cmd.append("D:/OneDrive - University of Cambridge/IAD-win-3-11-4/iad.exe")
    cmd.append("-q 12")  # number of quadrature points (default=8)
    cmd.append(f'-i 8')  # light is incident at this angle in degrees
    cmd.append(f'-g 0.7')  # fixed scattering anisotropy (default 0)
    cmd.append(path_rxt_T)
    subprocess.run(cmd)

class BioPixSDatasheet:
    def __init__(self, wave, mu_a_true, mu_sp_true):
        self.wave = wave
        self.mu_a_true = 0.1 * mu_a_true  # convert to [mm-1]
        self.mu_sp_true = 0.1 * mu_sp_true  # convert to [mm-1]

class Sample:
    def __init__(self, wave, mu_a_true, mu_sp_true, name):
        self.wave = wave
        self.mu_a_true = 0.1 * mu_a_true  # convert to [mm-1]
        self.mu_sp_true = 0.1 * mu_sp_true  # convert to [mm-1]
        self.name = name  # sample name

        # DIS measurement results
        self.wavelength = None
        self.thickness_B_squeeze = None
        self.thickness_B_nonsqueeze = None
        self.thickness_T_squeeze = None
        self.thickness_T_nonsqueeze = None
        # DIS measurement results: 8 cases
        # case 0: "/NoTape_0.985_thickness-/"
        # case 1: "/NoTape_rw_thickness-/"
        # case 2: "/NoTape_0.985_thickness+/"
        # case 3: "/NoTape_rw_thickness+/"
        # case 4: "/BlackTape_0.985_thickness-/"
        # case 5: "/BlackTape_rw_thickness-/"
        # case 6: "/BlackTape_0.985_thickness+/"
        # case 7: "/BlackTape_rw_thickness+/"
        self.cases = ["/NoTape_0.985_thickness-/", "/NoTape_rw_thickness-/", "/NoTape_0.985_thickness+/", "/NoTape_rw_thickness+/",
                      "/BlackTape_0.985_thickness-/", "/BlackTape_rw_thickness-/", "/BlackTape_0.985_thickness+/", "/BlackTape_rw_thickness+/"]
        self.case_labels = ["NoTape "+r'$r_w$'+"=0.985 d-", "NoTape "+r'$r_w$'+" d-", "NoTape "+r'$r_w$'+"=0.985 d+", "NoTape "+r'$r_w$'+" d+",
                            "BlackTape "+r'$r_w$'+"=0.985 d-", "BlackTape "+r'$r_w$'+" d-", "BlackTape "+r'$r_w$'+"=0.985 d+", "BlackTape "+r'$r_w$'+" d+"]
        self.mu_a_est = {
            "0": None, "1": None, "2": None, "3": None,
            "4": None, "5": None, "6": None, "7": None
        }
        self.mu_sp_est = {
            "0": None, "1": None, "2": None, "3": None,
            "4": None, "5": None, "6": None, "7": None
        }

        # For Bland-Altman plots, % difference
        self.mu_a_diff = {
            "0": None, "1": None, "2": None, "3": None,
            "4": None, "5": None, "6": None, "7": None
        }
        self.mu_sp_diff = {
            "0": None, "1": None, "2": None, "3": None,
            "4": None, "5": None, "6": None, "7": None
        }

    def read_txt(self, case):
        """
            this is to read .txt
            :param case: 8 cases
            :return: nothing
        """
        path_B_txt = PATH_IADResults + self.cases[case] + f"{self.name}" + "/B.txt"
        path_B_rxt = PATH_IADResults + self.cases[case] + f"{self.name}" + "/B.rxt"
        path_T_txt = PATH_IADResults + self.cases[case] + f"{self.name}" + "/T.txt"
        path_T_rxt = PATH_IADResults + self.cases[case] + f"{self.name}" + "/T.rxt"

        # if file does not exist, then do nothing and return
        if not os.path.isfile(path_B_txt):
            print(f"{path_B_txt} does not exist")
            return

        self.wavelength = np.loadtxt(path_B_txt, comments='#', usecols=0)
        if case in (0, 1, 4, 5):  # squeeze
            self.thickness_B_squeeze = np.loadtxt(path_B_rxt, comments='#', skiprows=7, max_rows=1)
            self.thickness_T_squeeze = np.loadtxt(path_T_rxt, comments='#', skiprows=7, max_rows=1)
        else:  # not squeeze
            self.thickness_B_nonsqueeze = np.loadtxt(path_B_rxt, comments='#', skiprows=7, max_rows=1)
            self.thickness_T_nonsqueeze = np.loadtxt(path_T_rxt, comments='#', skiprows=7, max_rows=1)

        mu_a_est_B = np.loadtxt(path_B_txt, comments='#', usecols=5)
        mu_sp_est_B = np.loadtxt(path_B_txt, comments='#', usecols=6)

        mu_a_est_T = np.loadtxt(path_T_txt, comments='#', usecols=5)
        mu_sp_est_T = np.loadtxt(path_T_txt, comments='#', usecols=6)

        self.mu_a_est[f'{case}'] = 0.5 * (mu_a_est_B + mu_a_est_T)
        self.mu_sp_est[f'{case}'] = 0.5 * (mu_sp_est_B + mu_sp_est_T)

    def plot_results(self, case, ax_mu_a, ax_mu_sp, color, marker, sample_idx):
        """
        this is to plot IAD results
        :param case: 8 cases
        :param ax_mu_a: mu_a plot handler
        :param ax_mu_p: mu_sp plot handler
        :param color: scatter color
        :param marker: scatter marker type
        :param sample_idx: if == 0, add legend/label
        :return: nothing
        """
        # if no results exist, do nothing and return
        if self.mu_a_est[f'{case}'] is None:
            return

        if sample_idx == 0:
            ax_mu_a.scatter(self.mu_a_true, self.mu_a_est[f'{case}'], label=self.case_labels[case], c=color, marker=marker)
            ax_mu_sp.scatter(self.mu_sp_true, self.mu_sp_est[f'{case}'], label=self.case_labels[case], c=color, marker=marker)
        else:
            ax_mu_a.scatter(self.mu_a_true, self.mu_a_est[f'{case}'], c=color, marker=marker)
            ax_mu_sp.scatter(self.mu_sp_true, self.mu_sp_est[f'{case}'], c=color, marker=marker)

        ax_mu_a.legend()
        ax_mu_a.set_xlabel("True " + r'$\mu_a \; \mathrm{(mm^{-1})}$')
        ax_mu_a.set_ylabel("Estimated " + r'$\mu_a \; \mathrm{(mm^{-1})}$')

        ax_mu_sp.legend()
        ax_mu_sp.set_xlabel("True " + r'$\mu_s^{\prime} \; \mathrm{(mm^{-1})}$')
        ax_mu_sp.set_ylabel("Estimated " + r'$\mu_s^{\prime} \; \mathrm{(mm^{-1})}$')

    def plot_Bland_Altman(self, case, ax_mu_a, ax_mu_sp, color, marker):
        """
        this is to plot Bland Altman plot
        :param case: 8 cases
        :param ax_mu_a: Bland-Altman mu_a plot handler
        :param ax_mu_sp: Bland-Altman mu_sp plot handler
        :param color: scatter color
        :param marker: scatter marker type
        :return: mu_a_diff, mu_sp_diff
        """
        # if no results exist, do nothing and return
        if self.mu_a_est[f'{case}'] is None:
            return np.array([]), np.array([])

        self.mu_a_diff[f'{case}'] = (self.mu_a_est[f'{case}'] - self.mu_a_true) / self.mu_a_true * 100
        self.mu_sp_diff[f'{case}'] = (self.mu_sp_est[f'{case}'] - self.mu_sp_true) / self.mu_sp_true * 100

        ax_mu_a.scatter(0.5 * (self.mu_a_true + self.mu_a_est[f'{case}']), self.mu_a_diff[f'{case}'],
                        label=self.name, c=color, marker=marker)
        ax_mu_sp.scatter(0.5 * (self.mu_sp_true + self.mu_sp_est[f'{case}']), self.mu_sp_diff[f'{case}'],
                         label=self.name, c=color, marker=marker)

        ax_mu_a.legend()
        ax_mu_a.set_xlabel("Average " + r'$\mu_a \; \mathrm{(mm^{-1})}$')
        ax_mu_a.set_ylabel("Difference (%)")

        ax_mu_sp.legend()
        ax_mu_sp.set_xlabel("Average " + r'$\mu_s^{\prime} \; \mathrm{(mm^{-1})}$')
        ax_mu_sp.set_ylabel("Difference (%)")

        return self.mu_a_diff[f'{case}'], self.mu_sp_diff[f'{case}']


if __name__ == '__main__':
    A2_BioPixS = BioPixSDatasheet(wave=np.array([600, 780]), mu_a_true=np.array([0.06, 0.05]), mu_sp_true=np.array([7.3, 5.4]))
    B2_BioPixS = BioPixSDatasheet(wave=np.array([500, 600, 780, 900]),
                                  mu_a_true=np.array([0.06, 0.06, 0.05, 0.11]),
                                  mu_sp_true=np.array([14.7, 13.2, 10.2, 8.2]))
    B3_BioPixS = BioPixSDatasheet(wave=np.array([500, 600, 690, 740, 780, 830, 900, 950]),
                        mu_a_true=np.array([0.12, 0.12, 0.11, 0.12, 0.1, 0.1, 0.16, 0.11]),
                        mu_sp_true=np.array([15, 13.1, 11.5, 10.7, 10, 9.2, 8.2, 7.7]))
    B5_BioPixS = BioPixSDatasheet(wave=np.array([500, 600, 780, 900]),
                                  mu_a_true=np.array([0.24, 0.23, 0.2, 0.27]),
                                  mu_sp_true=np.array([15.2, 13, 10, 8.5]))
    B7_BioPixS = BioPixSDatasheet(wave=np.array([500, 600, 780, 900]),
                        mu_a_true=np.array([0.36, 0.36, 0.31, 0.38]), mu_sp_true=np.array([15, 13.5, 10.5, 8.9]))
    C2_BioPixS = BioPixSDatasheet(wave=np.array([600, 780]), mu_a_true=np.array([0.06, 0.05]),
                                  mu_sp_true=np.array([19.7, 15]))
    C3_BioPixS = BioPixSDatasheet(wave=np.array([600, 780]), mu_a_true=np.array([0.12, 0.1]),
                                  mu_sp_true=np.array([19.8, 15.2]))
    C5_BioPixS = BioPixSDatasheet(wave=np.array([600, 780]), mu_a_true=np.array([0.24, 0.21]), mu_sp_true=np.array([19.8, 15.4]))
    C7_BioPixS = BioPixSDatasheet(wave=np.array([600, 780]), mu_a_true=np.array([0.35, 0.31]),
                                  mu_sp_true=np.array([19.9, 15.5]))
    D7_BioPixS = BioPixSDatasheet(wave=np.array([600, 780]), mu_a_true=np.array([0.35, 0.3]), mu_sp_true=np.array([25.6, 19.8]))

    # phantom_name_list = ["BioPixS_A2", "BioPixS_B3", "BioPixS_B7", "BioPixS_C5", "BioPixS_D7"]
    # phantom_list = [A2_BioPixS, B3_BioPixS, B7_BioPixS, C5_BioPixS, D7_BioPixS]

    phantom_name_list = ["BioPixS_C2_2", "BioPixS_C3_2"]
    phantom_list = [C2_BioPixS, C3_BioPixS]

    # """Run IAD"""
    # for phantom_idx, phantom_name in enumerate(phantom_name_list):
    #     # run_iad(PATH_NoTape + "/" + phantom_name, PATH_IADResults + "/NoTape_0.985_thickness-/" + phantom_name,
    #     #         phantom_list[phantom_idx].wave, rw=False, thickness_squeeze=True)
    #     # run_iad(PATH_NoTape + "/" + phantom_name, PATH_IADResults + "/NoTape_rw_thickness-/" + phantom_name,
    #     #         phantom_list[phantom_idx].wave, rw=True, thickness_squeeze=True)
    #     # run_iad(PATH_NoTape + "/" + phantom_name, PATH_IADResults + "/NoTape_0.985_thickness+/" + phantom_name,
    #     #         phantom_list[phantom_idx].wave, rw=False, thickness_squeeze=False)
    #     # run_iad(PATH_NoTape + "/" + phantom_name, PATH_IADResults + "/NoTape_rw_thickness+/" + phantom_name,
    #     #         phantom_list[phantom_idx].wave, rw=True, thickness_squeeze=False)
    #     run_iad(PATH_BlackTape + "/" + phantom_name, PATH_IADResults + "/BlackTape_0.985_thickness-/" + phantom_name,
    #             phantom_list[phantom_idx].wave, rw=False, thickness_squeeze=True)
    #     run_iad(PATH_BlackTape + "/" + phantom_name, PATH_IADResults + "/BlackTape_rw_thickness-/" + phantom_name,
    #             phantom_list[phantom_idx].wave, rw=True, thickness_squeeze=True)
    #     run_iad(PATH_BlackTape + "/" + phantom_name, PATH_IADResults + "/BlackTape_0.985_thickness+/" + phantom_name,
    #             phantom_list[phantom_idx].wave, rw=False, thickness_squeeze=False)
    #     run_iad(PATH_BlackTape + "/" + phantom_name, PATH_IADResults + "/BlackTape_rw_thickness+/" + phantom_name,
    #             phantom_list[phantom_idx].wave, rw=True, thickness_squeeze=False)

    """Read Results"""
    A2 = Sample(wave=np.array([600, 780]), mu_a_true=np.array([0.06, 0.05]), mu_sp_true=np.array([7.3, 5.4]),
                name="BioPixS_A2")
    B2 = Sample(wave=np.array([500, 600, 780, 900]),
                mu_a_true=np.array([0.06, 0.06, 0.05, 0.11]), mu_sp_true=np.array([14.7, 13.2, 10.2, 8.2]),
                name="BioPixS_B2_2")
    B3 = Sample(wave=np.array([500, 600, 690, 740, 780, 830, 900, 950]),
                mu_a_true=np.array([0.12, 0.12, 0.11, 0.12, 0.1, 0.1, 0.16, 0.11]),
                mu_sp_true=np.array([15, 13.1, 11.5, 10.7, 10, 9.2, 8.2, 7.7]),
                name="BioPixS_B3")
    B5 = Sample(wave=np.array([500, 600, 780, 900]),
                mu_a_true=np.array([0.24, 0.23, 0.2, 0.27]), mu_sp_true=np.array([15.2, 13, 10, 8.5]),
                name="BioPixS_B5")
    B7 = Sample(wave=np.array([500, 600, 780, 900]),
                mu_a_true=np.array([0.36, 0.36, 0.31, 0.38]), mu_sp_true=np.array([15, 13.5, 10.5, 8.9]),
                name="BioPixS_B7")
    C2 = Sample(wave=np.array([600, 780]), mu_a_true=np.array([0.06, 0.05]), mu_sp_true=np.array([19.7, 15]),
                name="BioPixS_C2_2")
    C3 = Sample(wave=np.array([600, 780]), mu_a_true=np.array([0.12, 0.1]), mu_sp_true=np.array([19.8, 15.2]),
                name="BioPixS_C3_2")
    C5 = Sample(wave=np.array([600, 780]), mu_a_true=np.array([0.24, 0.21]), mu_sp_true=np.array([19.8, 15.4]),
                name="BioPixS_C5")
    C7 = Sample(wave=np.array([600, 780]), mu_a_true=np.array([0.35, 0.31]), mu_sp_true=np.array([19.9, 15.5]),
                name="BioPixS_C7")
    D7 = Sample(wave=np.array([600, 780]), mu_a_true=np.array([0.35, 0.3]), mu_sp_true=np.array([25.6, 19.8]),
                name="BioPixS_D7")
    sample_list = [A2, B2, B3, B5, B7, C2, C3, C5, C7, D7]
    for sample in sample_list:
        for case in range(8):
            # case 0: "/NoTape_0.985_thickness-/"
            # case 1: "/NoTape_rw_thickness-/"
            # case 2: "/NoTape_0.985_thickness+/"
            # case 3: "/NoTape_rw_thickness+/"
            # case 4: "/BlackTape_0.985_thickness-/"
            # case 5: "/BlackTape_rw_thickness-/"
            # case 6: "/BlackTape_0.985_thickness+/"
            # case 7: "/BlackTape_rw_thickness+/"
            sample.read_txt(case)
        print(f"{sample.name}: {sample.thickness_B_squeeze}, {sample.thickness_T_squeeze}, "
              f"{sample.thickness_B_nonsqueeze}, {sample.thickness_T_nonsqueeze}, \n"
              f"{sample.mu_a_est}, \n{sample.mu_sp_est}\n")

    """Plot Results"""
    _, ax_mu_a = plt.subplots(num="DIS mu_a v.s. True mu_a")
    ax_mu_a.plot(np.array([0, 0.05]), np.array([0, 0.05]), c="black")
    _, ax_mu_sp = plt.subplots(num="DIS mu_sp v.s. True mu_sp")
    ax_mu_sp.plot(np.array([0.2, 3]), np.array([0.2, 3]), c="black")

    # Bland Altman Plots for 8 Cases
    # case 0: "/NoTape_0.985_thickness-/"
    # case 1: "/NoTape_rw_thickness-/"
    # case 2: "/NoTape_0.985_thickness+/"
    # case 3: "/NoTape_rw_thickness+/"
    # case 4: "/BlackTape_0.985_thickness-/"
    # case 5: "/BlackTape_rw_thickness-/"
    # case 6: "/BlackTape_0.985_thickness+/"
    # case 7: "/BlackTape_rw_thickness+/"
    BA_bias_mu_a = np.zeros(8)
    BA_std_mu_a = np.zeros(8)
    BA_bias_mu_sp = np.zeros(8)
    BA_std_mu_sp = np.zeros(8)
    _, ax_BA_0_mu_a = plt.subplots(num="BA NoTape rw=0.985 d- Bland Altman mu_a")
    _, ax_BA_0_mu_sp = plt.subplots(num="BA NoTape rw=0.985 d- Bland Altman mu_sp")
    _, ax_BA_1_mu_a = plt.subplots(num="BA NoTape rw d- Bland Altman mu_a")
    _, ax_BA_1_mu_sp = plt.subplots(num="BA NoTape rw d- Bland Altman mu_sp")
    _, ax_BA_2_mu_a = plt.subplots(num="BA NoTape rw=0.985 d+ Bland Altman mu_a")
    _, ax_BA_2_mu_sp = plt.subplots(num="BA NoTape rw=0.985 d+ Bland Altman mu_sp")
    _, ax_BA_3_mu_a = plt.subplots(num="BA NoTape rw d+ Bland Altman mu_a")
    _, ax_BA_3_mu_sp = plt.subplots(num="BA NoTape rw d+ Bland Altman mu_sp")
    _, ax_BA_4_mu_a = plt.subplots(num="BA BlackTape rw=0.985 d- Bland Altman mu_a")
    _, ax_BA_4_mu_sp = plt.subplots(num="BA BlackTape rw=0.985 d- Bland Altman mu_sp")
    _, ax_BA_5_mu_a = plt.subplots(num="BA BlackTape rw d- Bland Altman mu_a")
    _, ax_BA_5_mu_sp = plt.subplots(num="BA BlackTape rw d- Bland Altman mu_sp")
    _, ax_BA_6_mu_a = plt.subplots(num="BA BlackTape rw=0.985 d+ Bland Altman mu_a")
    _, ax_BA_6_mu_sp = plt.subplots(num="BA BlackTape rw=0.985 d+ Bland Altman mu_sp")
    _, ax_BA_7_mu_a = plt.subplots(num="BA BlackTape rw d+ Bland Altman mu_a")
    _, ax_BA_7_mu_sp = plt.subplots(num="BA BlackTape rw d+ Bland Altman mu_sp")
    data_BA_0_mu_a = np.array([])
    data_BA_1_mu_a = np.array([])
    data_BA_2_mu_a = np.array([])
    data_BA_3_mu_a = np.array([])
    data_BA_4_mu_a = np.array([])
    data_BA_5_mu_a = np.array([])
    data_BA_6_mu_a = np.array([])
    data_BA_7_mu_a = np.array([])
    data_BA_0_mu_sp = np.array([])
    data_BA_1_mu_sp = np.array([])
    data_BA_2_mu_sp = np.array([])
    data_BA_3_mu_sp = np.array([])
    data_BA_4_mu_sp = np.array([])
    data_BA_5_mu_sp = np.array([])
    data_BA_6_mu_sp = np.array([])
    data_BA_7_mu_sp = np.array([])

    ax_BA_mu_a_list = [ax_BA_0_mu_a, ax_BA_1_mu_a, ax_BA_2_mu_a, ax_BA_3_mu_a,
                       ax_BA_4_mu_a, ax_BA_5_mu_a, ax_BA_6_mu_a, ax_BA_7_mu_a]
    ax_BA_mu_sp_list = [ax_BA_0_mu_sp, ax_BA_1_mu_sp, ax_BA_2_mu_sp, ax_BA_3_mu_sp,
                        ax_BA_4_mu_sp, ax_BA_5_mu_sp, ax_BA_6_mu_sp, ax_BA_7_mu_sp]
    data_BA_mu_a_list = [data_BA_0_mu_a, data_BA_1_mu_a, data_BA_2_mu_a, data_BA_3_mu_a,
                         data_BA_4_mu_a, data_BA_5_mu_a, data_BA_6_mu_a, data_BA_7_mu_a]
    data_BA_mu_sp_list = [data_BA_0_mu_sp, data_BA_1_mu_sp, data_BA_2_mu_sp, data_BA_3_mu_sp,
                         data_BA_4_mu_sp, data_BA_5_mu_sp, data_BA_6_mu_sp, data_BA_7_mu_sp]
    BA_bias_mu_a = np.zeros(8)
    BA_std_mu_a = np.zeros(8)
    BA_bias_mu_sp = np.zeros(8)
    BA_std_mu_sp = np.zeros(8)

    # color list for cases
    color_list = ["tab:cyan", "tab:olive", "tab:brown", "tab:purple",
                  "tab:blue", "tab:green", "tab:gray", "tab:red"]
    # marker list for samples
    marker_list = [".", "1", "2", "3", "4", "+", "x", "|", "_", "*"]
    """mu_a, mu_sp Plots and Bland-Altman Plots"""
    for sample_idx, sample in enumerate(sample_list):
        for case in range(8):
            sample.plot_results(case, ax_mu_a, ax_mu_sp, color_list[case], marker_list[sample_idx], sample_idx)
            mu_a_diff, mu_sp_diff = sample.plot_Bland_Altman(case, ax_BA_mu_a_list[case], ax_BA_mu_sp_list[case],
                                                             color_list[case], marker_list[sample_idx])
            data_BA_mu_a_list[case] = np.append(data_BA_mu_a_list[case], mu_a_diff)
            data_BA_mu_sp_list[case] = np.append(data_BA_mu_sp_list[case], mu_sp_diff)

    """Add Bias and Std on Bland-Altman Plots"""
    for case in range(8):
        BA_bias_mu_a[case] = np.mean(data_BA_mu_a_list[case])
        BA_std_mu_a[case] = np.std(data_BA_mu_a_list[case])
        BA_bias_mu_sp[case] = np.mean(data_BA_mu_sp_list[case])
        BA_std_mu_sp[case] = np.std(data_BA_mu_sp_list[case])

        ax_BA_mu_a_list[case].axhline(BA_bias_mu_a[case], c='black', label="Bias")
        ax_BA_mu_a_list[case].axhline(BA_bias_mu_a[case] - 1.96*BA_std_mu_a[case], c='black', linestyle=':', label="1.96 Std")
        ax_BA_mu_a_list[case].axhline(BA_bias_mu_a[case] + 1.96*BA_std_mu_a[case], c='black', linestyle=':')
        ax_BA_mu_a_list[case].legend(ncol=3, loc=(0, 1.1))

        ax_BA_mu_sp_list[case].axhline(BA_bias_mu_sp[case], c='black', label="Bias")
        ax_BA_mu_sp_list[case].axhline(BA_bias_mu_sp[case] - 1.96*BA_std_mu_sp[case], c='black', linestyle=':', label="1.96 Std")
        ax_BA_mu_sp_list[case].axhline(BA_bias_mu_sp[case] + 1.96*BA_std_mu_sp[case], c='black', linestyle=':')
        ax_BA_mu_sp_list[case].legend(ncol=3, loc=(0, 1.1))

    """Plot Bland-Altman Trend v.s. Cases"""
    case_labels = ["No Tape\n"+r'$r_w$'+"=0.985\nd-", "No Tape\n"+r'$r_w$'+"\nd-", "No Tape\n"+r'$r_w$'+"=0.985\nd+", "No Tape\n"+r'$r_w$'+"\nd+",
                   "Black Tape\n"+r'$r_w$'+"=0.985\nd-", "Black Tape\n"+r'$r_w$'+"\nd-", "Black Tape\n"+r'$r_w$'+"=0.985\nd+", "Black Tape\n"+r'$r_w$'+"\nd+"]
    _, ax_BA_trend = plt.subplots(num="Bland Altman Trend")
    ax_BA_trend.errorbar(np.arange(8), BA_bias_mu_a, yerr=BA_std_mu_a, capsize=2, linestyle='', marker='o', label=r'$\mu_a$')
    ax_BA_trend.errorbar(np.arange(8), BA_bias_mu_sp, yerr=BA_std_mu_sp, capsize=2, linestyle='', marker='o', label=r'$\mu_s^{\prime}$')
    ax_BA_trend.axhline(0, label="0 Error", c='black')
    ax_BA_trend.set_xticks(np.arange(8), case_labels, rotation='vertical')
    ax_BA_trend.set_ylabel("Difference (%)")
    ax_BA_trend.legend()
    plt.subplots_adjust(bottom=0.2)

    """Plots thickness- and thickness+"""
    phantom_name_list = ["BioPixS\nA2",
                         "BioPixS\nB2_2", "BioPixS\nB3", "BioPixS\nB5", "BioPixS\nB7",
                         "BioPixS\nC2_2", "BioPixS\nC3_2", "BioPixS\nC5", "BioPixS\nC7",
                         "BioPixS\nD7"]
    _, ax_thickness = plt.subplots(num="Thickness")
    for sample_idx, sample in enumerate(sample_list):
        if sample_idx == 0:  # add labels for the first sample
            ax_thickness.scatter(sample_idx, sample.thickness_B_squeeze, label="d-", c="tab:blue")
            ax_thickness.scatter(sample_idx, sample.thickness_T_squeeze, c="tab:blue")
            ax_thickness.scatter(sample_idx, sample.thickness_B_nonsqueeze, label="d+", c="tab:orange")
            ax_thickness.scatter(sample_idx, sample.thickness_T_nonsqueeze, c="tab:orange")
        ax_thickness.scatter(sample_idx, sample.thickness_B_squeeze, c="tab:blue")
        ax_thickness.scatter(sample_idx, sample.thickness_T_squeeze, c="tab:blue")
        ax_thickness.scatter(sample_idx, sample.thickness_B_nonsqueeze, c="tab:orange")
        ax_thickness.scatter(sample_idx, sample.thickness_T_nonsqueeze, c="tab:orange")
    ax_thickness.axhline(2.3, label="Nominal d", c='black')
    ax_thickness.set_xticks(np.arange(len(phantom_name_list)), phantom_name_list, rotation='vertical')
    ax_thickness.set_ylabel("Thickness d (mm)")
    ax_thickness.legend()
    plt.subplots_adjust(bottom=0.15)

    plt.show()